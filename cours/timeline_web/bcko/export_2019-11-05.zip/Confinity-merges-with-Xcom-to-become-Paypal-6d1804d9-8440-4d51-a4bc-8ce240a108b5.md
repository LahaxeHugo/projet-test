# Confinity merges with Xcom to become Paypal

Année: 1998
Catégorie: Launch 🚀
Mois - Jour: 15 Mars

