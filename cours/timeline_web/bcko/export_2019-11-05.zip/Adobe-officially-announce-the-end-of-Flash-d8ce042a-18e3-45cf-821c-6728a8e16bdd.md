# Adobe officially announce the end of Flash.

Année: 2015
Catégorie: Announcement
Mois - Jour: 30 Novembre
État: Complet ✅

Years ago, flash was used all over the web for making games or animation, because at that time there was no other easy way. But nowadays, it's outdated. 

![](Untitled-f0c36b89-ef98-4e54-9511-735da152a866.png)