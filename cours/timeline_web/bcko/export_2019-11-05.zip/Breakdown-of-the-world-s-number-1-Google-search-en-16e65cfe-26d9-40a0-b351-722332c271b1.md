# Breakdown of the world's number 1 Google search engine

Année: 2009
Catégorie: Navigation/Moteurs de recherche
Credits: https://geeko.lesoir.be/2019/06/02/google-victime-dune-gigantesque-panne/
Credits: https://www.lepoint.fr/high-tech-internet/google-bug-la-faiblesse-est-humaine-le-geant-des-moteurs-de-recherche-aussi-01-02-2009-312616_47.php
Mois - Jour: Février
État: Complet ✅

Google had an incredible failure in February2009. For just under an hour, the search giant on the Internet has classified all websites in the world as "dangerous", warning the net surfers of the so-called "danger" if they continued their navigation. The bug came from the system used by Google to block access to really dangerous sites. The search engine maintains a blacklist of websites with dangerous content, such as viruses or spyware. The goal is to protect users, sometimes unaware of the dangers of the Web. On his official blog, Google explains that "it was clearly a mistake, and we are sorry." Not seeking to invoke a technical problem, the search engine immediately admits "a human error, simply". For insiders, Google has mistakenly checked the domain "/" in the blacklist, which has been translated by the ranking of the entire Web in banned sites. Google has about 70% of the market share of Internet research.

![](Untitled-f8b2772b-84f4-48cb-965b-36e278e195e0.png)