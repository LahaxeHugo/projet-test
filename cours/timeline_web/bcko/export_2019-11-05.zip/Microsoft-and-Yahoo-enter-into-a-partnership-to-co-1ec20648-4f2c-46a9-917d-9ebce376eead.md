# Microsoft and Yahoo enter into a partnership to compete with Google in the field of web search.

Année: 2009
Catégorie: Acquisition 💰
Mois - Jour: 29 Juillet

