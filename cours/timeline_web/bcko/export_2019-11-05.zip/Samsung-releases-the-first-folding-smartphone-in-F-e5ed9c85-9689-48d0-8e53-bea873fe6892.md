# Samsung releases the first folding smartphone in France: the Galaxy Fold

Année: 2019
Catégorie: Innovation 🎢
Mois - Jour: 18 septembre
État: Complet ✅

The Galaxy Fold is a real innovation since the touch screens, and marks the beginning of a new era in the field of smartphones. It is similar to a tablet that can be put in pocket.

![](Untitled-ba91f54d-2863-4745-8513-05092aa8221c.png)