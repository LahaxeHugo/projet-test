# Google’s artificially intelligent Go-playing computer system has defeated Korean grandmaster Lee Sedol, finishing the best-of-five series with four wins and one loss.

Année: 2016
Catégorie: Innovation 🎢
Mois - Jour: 15 Mars
État: Complet ✅

A confrontation to determine who, the man or the machine, is the strongest. The AlphaGo program won its third consecutive victory in a five-part series in Seoul against Lee Sedol, who has dominated the game of go for a decade.

src: [https://www.lepoint.fr/monde/le-champion-du-monde-du-jeu-de-go-battu-par-l-ordinateur-12-03-2016-2024850_24.php](https://www.lepoint.fr/monde/le-champion-du-monde-du-jeu-de-go-battu-par-l-ordinateur-12-03-2016-2024850_24.php)

![](Untitled-e99e3e97-781a-4a2d-aaca-41194c840dca.png)