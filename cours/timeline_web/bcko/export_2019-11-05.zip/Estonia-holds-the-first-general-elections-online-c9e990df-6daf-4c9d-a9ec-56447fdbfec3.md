# Estonia holds the first general elections online

Année: 2007
Catégorie: Innovation 🎢
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html
Mois - Jour: 4 Mars
État: Complet ✅

Estonia became the first country in the world to allow electronic voting for an election of this size. Twelve years later, votes of this kind continue to provoke controversy.

This voting system builds on the Estonian ID card. It is used as a regular and mandatory national identity document allowing secure remote authentication and legally binding digital signatures by using the Estonian state supported public key infrastructure.

In March 2007, over 1.08 million cards have been issued (population of 1.32 million)