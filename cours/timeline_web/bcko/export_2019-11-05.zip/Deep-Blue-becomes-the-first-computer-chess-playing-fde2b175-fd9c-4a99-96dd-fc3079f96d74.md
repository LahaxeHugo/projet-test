# Deep Blue becomes the first computer chess-playing system to beat a reigning world chess champion, Garry Kasparov

Année: 1997
Catégorie: Innovation 🎢
Mois - Jour: 11 Mai

