# Creation of the DADVSI law

Année: 2006
Catégorie: Law 👨‍⚖️
Mois - Jour: 30 Juin

Adoption of Law No. 2006-961 known as DADVSI, on Copyright and Neighboring Rights in the Information Society. It transposes the European directive of 22 May 2001 and adapts copyright legislation to the development of digital techniques. It also expands the legal deposit to Internet sites in order to archive the Web. In particular, incarcerates 3 years in prison any person publishing a software allowing the putting on line of protected works without authorization.