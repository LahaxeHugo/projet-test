# Launch of Creative Commons licenses

Année: 2002
Catégorie: Law 👨‍⚖️
Credits: https://scinfolex.com/2016/01/19/archives-ouvertes-et-licences-creative-commons-des-synergies-a-conforter/
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html
Mois - Jour: 16 Décembre 
État: Complet ✅

These licenses, designed by US law professor Lawrence Lessig, allow creators to broadcast their works on the Internet, defining what others can and can not do with their works. Very popular, they were adapted in 2004 to French law.

![](Untitled-4a5e0e34-c774-4731-8427-4fa30a34f22a.png)