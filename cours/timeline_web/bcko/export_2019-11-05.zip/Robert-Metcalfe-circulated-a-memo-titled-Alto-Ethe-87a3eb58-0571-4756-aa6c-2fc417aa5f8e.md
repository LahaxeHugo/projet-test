# Robert Metcalfe circulated a memo titled "Alto Ethernet" which contained a rough schematic of ethernet would work

Année: 1973
Catégorie: Publishing 📚
Mois - Jour: 22 Avril

Robert Metcalfe wrote a memo in order to describe a way to transmit data from the early generation of personal computers to a new device, the laser printer. 

He named the new network technology Ethernet. It refers instead to a discredited scientific theory of the luminiferous aether, an undifferentiated universal medium that some 18th- and 19th-century scientists thought necessary for the propagation of light. Metcalfe saw it as an apt metaphor for a medium that would propagate information.

Over time, Ethernet has largely replaced competing wired LAN technologies.