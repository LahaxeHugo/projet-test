# Microsoft repurchases LinkedIn for $26.2 billion

Année: 2016
Catégorie: Acquisition 💰
Mois - Jour: 13 Juin
État: Complet ✅

Microsoft has announced plans to acquire LinkedIn, the social network for professionals. The Redmond company plans to pay $ 196 per share, which will evaluate the social network at $ 26.2 billion. Microsoft promises that LinkedIn will remain independent with Jeff Weiner in the lead, he will report to Satya Nadella, the CEO of Microsoft. This acquisition constitutes the largest acquisition transaction by Microsoft and the first major acquisition of Satya Nadella.

src : [https://www.developpez.com/actu/99857/Microsoft-va-racheter-LinkedIn-pour-26-2-milliards-de-dollars-mais-pourquoi-la-firme-de-Redmond-s-interesse-t-elle-au-reseau-professionnel/](https://www.developpez.com/actu/99857/Microsoft-va-racheter-LinkedIn-pour-26-2-milliards-de-dollars-mais-pourquoi-la-firme-de-Redmond-s-interesse-t-elle-au-reseau-professionnel/)

![](Untitled-107b2ceb-edf8-4dc4-972f-a379d2479aa9.png)