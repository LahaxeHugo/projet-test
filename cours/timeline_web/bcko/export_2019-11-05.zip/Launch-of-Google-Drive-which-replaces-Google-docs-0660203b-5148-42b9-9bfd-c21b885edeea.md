# Launch of Google Drive, which replaces Google docs

Année: 2012
Catégorie: Launch 🚀
Mois - Jour: 24 avril
État: Complet ✅

Google Drive is a cloud-based storage and sharing service launched by Google. It is an office suite for editing documents, spreadsheets, presentations, drawings, forms, etc.
Google Drive replaces Google Docs when active. Existing documents on Google Docs are automatically uploaded to Google Drive. It is used to synchronize, share and modify data between multiple computers and / or users.

src : [https://fr.wikipedia.org/wiki/Google_Drive](https://fr.wikipedia.org/wiki/Google_Drive)

![](Untitled-ec910ad5-f501-4e0f-a9da-599de3070b5f.png)