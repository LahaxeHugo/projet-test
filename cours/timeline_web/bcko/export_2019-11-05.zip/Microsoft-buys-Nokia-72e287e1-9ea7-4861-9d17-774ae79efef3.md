# Microsoft buys Nokia

Année: 2013
Catégorie: Acquisition 💰
Mois - Jour: 3 septembre
État: Complet ✅

The main reason for taking over Nokia's mobile business is unification. With this operation, Microsoft has for the first time a clear outlet on all screens: Windows on PCs, the Xbox on TV, tablets with Surface and smartphones with Lumia.

src: [https://www.nextinpact.com/news/82122-rachat-division-mobile-nokia-enjeux-et-defis-microsoft.htm](https://www.nextinpact.com/news/82122-rachat-division-mobile-nokia-enjeux-et-defis-microsoft.htm)

![](Untitled-a1f30077-1d9d-48a4-8986-99120dcf5889.png)