# Creation of the 1st online contributive encyclopedia : larousse.fr

Année: 2008
Catégorie: Launch 🚀
Mois - Jour: 13 Mai
État: Complet ✅

Launch of [larousse.fr](http://larousse.fr/) website by Larousse publisher, allowing free access to both the encyclopedia and the contributions of clearly identified Internet users. This is the first contributory encyclopaedia on the Internet from a historical encyclopedia.

![](Untitled-ef15711f-7c2f-4cd2-9f39-38b94458b6ea.png)