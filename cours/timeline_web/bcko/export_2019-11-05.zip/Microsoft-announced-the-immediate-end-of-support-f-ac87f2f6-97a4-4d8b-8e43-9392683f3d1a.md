# Microsoft announced the immediate end of support for Windows Phone.

Année: 2017
Catégorie: Announcement
Mois - Jour: 11 Juillet
État: Complet ✅

Microsoft is now focusing its mobile efforts on building apps and services for iOS and Android devices. The software giant has embraced Android as the mobile version of Windows

src: [https://www.theverge.com/2019/1/18/18188054/microsoft-windows-phone-windows-10-mobile-end-of-support-updates](https://www.theverge.com/2019/1/18/18188054/microsoft-windows-phone-windows-10-mobile-end-of-support-updates)

![](Untitled-ecebec83-629c-46f8-b4b9-4ffe706a4f04.png)