# Initial release of html5

Année: 2014
Catégorie: Launch 🚀
Mois - Jour: 28 Octobre
État: Complet ✅

HTML5 is an evolution of HTML 4.01 (and XHTML 1.0), which means that everything we know about HTML remains valid. This evolution consists of a multitude of new features that have been made to HTML and Javascript.

src: [https://www.aurone.com/les-nouveautés-apportées-par-html-5](https://www.aurone.com/les-nouveaut%C3%A9s-apport%C3%A9es-par-html-5)

![](Untitled-9077d37e-0844-4e54-8bc8-ca184d32d9ce.png)