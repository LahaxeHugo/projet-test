# Arpanet (Advanced Research Projects Agency Network) is attached to the NSFnet (The National Science Foundation Network).

Année: 1990
Catégorie: Navigation/Moteurs de recherche

In 1980, Arpanet is divided in 2 separate networks : one military (MILNET, de Military Network, that will become  DDN — Defense Data Network) and the other one university (NSFnet), that militaries gives to the civil world. 
The constructors wanted a decentralized computing.