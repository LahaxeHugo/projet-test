# First banner ad

Année: 1994
Catégorie: Images on the web 🖼
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html

The first advertising on the web was displayed  on hotwired.com, promoting a news website from [lemonde.fr](http://lemonde.fr) : 3615pixels.com.

This ad was just the first of many, it shaped the economic system of the web nowadays.

![](Untitled-529076c2-1773-4f63-9dd1-90bc26747435.png)