# Google doubles the length of descriptions

Année: 2017
Catégorie: Innovation 🎢
Credits: image: http://bestseo-services.blogspot.com/2017/12/What-is-the-latest-Google-Tag-Description-Length.html
Credits: https://blog.hubspot.fr/marketing/algorithmes-google
Mois - Jour: Novembre
État: Complet ✅

![](Google_Meta_Tag_in_Desktop-89ba17c9-53f8-4245-915b-407f24f3707d.png)

In November 2017, Google doubled the number of characters displayed in the result descriptions from a limit of 160 characters to a limit of 320 characters.

With this update, Google continues to promote complete sentences and descriptions that contain enough information to provide context to readers. It is possible that the search engine does not take into account your meta-description tag and cut or complete some descriptions.

Reminder: Meta-descriptions do not count in search engine rankings, but are still essential to encourage your visitors to come to your site.