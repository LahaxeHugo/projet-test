# Google launches Google Adwords

Année: 2001
Catégorie: Innovation 🎢,Launch 🚀
Credits: https://www.tiki-toki.com/timeline/entry/137139/Chronologie-du-rseau-internet/#vars!date=1976-03-03_15:26:50!
Mois - Jour: Mai
État: Complet ✅

Launch by Google of Google Adwords, which allows the display of advertisements corresponding to the words used by the user for his research.