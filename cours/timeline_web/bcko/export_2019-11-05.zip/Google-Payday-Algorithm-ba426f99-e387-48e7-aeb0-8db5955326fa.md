# Google Payday Algorithm

Année: 2013
Catégorie: Launch 🚀
Credits: image : http://www.seodesk.co.uk/google-payday-loan-algorithm-update-3-0/
Credits: https://www.webhopers.com/google-payday-algorithm
Mois - Jour: 4 Juin
État: Complet ✅

![](google_payday-fe925acb-8b4e-477e-869b-2810d189c596.jpg)

Google Payday algorithm is a set of different algorithm updates whose main purpose is to identify and penalize the websites that uses search engine spam techniques to improve their ranks and traffic. We agree that ranking takes a lot of effort and dedication but using illegal ways is definitely not a good idea to rank high. 

Google payday algorithm is a step to filter out the low quality websites that uses spam to boost their rankings.