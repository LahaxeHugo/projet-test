# First stable version of Firefox

Année: 2004
Catégorie: Launch 🚀
Mois - Jour: 9 Novembre

