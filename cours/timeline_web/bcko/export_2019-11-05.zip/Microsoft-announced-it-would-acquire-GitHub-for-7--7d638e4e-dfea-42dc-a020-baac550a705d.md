# Microsoft announced it would acquire GitHub for $7.5 billion.

Année: 2018
Catégorie: Acquisition 💰
Mois - Jour: 4 Juin
État: Complet ✅

As a result, people are scared that github will no longer be open source. Nevertheless, the acquisition will provide developers with new tools at each stage of software development, enabling them to provide new services to their users.

![](Untitled-fa12327c-da87-427e-86fb-04a4a42468d4.png)