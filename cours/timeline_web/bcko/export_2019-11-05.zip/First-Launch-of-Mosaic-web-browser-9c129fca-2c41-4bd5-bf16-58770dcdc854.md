# First Launch of Mosaic web browser

Année: 1993
Catégorie: Launch 🚀
Mois - Jour: 5 Janvier

![](mosaic_logo-c8b855d5-35a1-4753-8cba-600f93d615c9.jpg)

On April 22, 1993, version 1.0 Mosaic, was released, the web browser credited with popularizing the World Wide Web. 

It was the first Web browser as we know today with a graphical user interface enabling an interactive easy to use browsing experience. And without graphics the Web as we know it today would not exist.

Mosaic was the web browser that led to the Internet boom of the 1990s.

[https://www.wiselyguide.com/mosaic-first-web-browser-25-years-old/](https://www.wiselyguide.com/mosaic-first-web-browser-25-years-old/)

[http://scihi.org/ncsa-mosaic-web/](http://scihi.org/ncsa-mosaic-web/)