# Launch of Spotify

Année: 2008
Catégorie: Launch 🚀
Mois - Jour: 7 Octobre

