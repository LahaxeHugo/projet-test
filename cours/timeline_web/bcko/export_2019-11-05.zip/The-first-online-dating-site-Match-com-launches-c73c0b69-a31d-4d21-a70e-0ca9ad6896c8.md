# The first online dating site, [Match.com](http://match.com/), launches.

Année: 1995
Catégorie: Launch 🚀

![](matchlogo_blue_310x206-5f986f74-49ef-477c-ba6b-aa56eb3a6384.png)