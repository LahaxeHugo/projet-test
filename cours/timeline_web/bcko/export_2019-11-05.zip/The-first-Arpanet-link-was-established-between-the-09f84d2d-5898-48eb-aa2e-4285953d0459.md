# The first Arpanet link was established between the University of California, Los Angeles (UCLA) and the Stanford Research Institute at 22:30 hours.

Année: 1969
Catégorie: Innovation 🎢
Mois - Jour: 29 Octobre

The Advanced Research Projects Agency Network (ARPANET) was an early packet-switching network and the first network to implement the TCP/IP protocol suite. Both technologies became the technical foundation of the Internet.

It marked the start of a new era.