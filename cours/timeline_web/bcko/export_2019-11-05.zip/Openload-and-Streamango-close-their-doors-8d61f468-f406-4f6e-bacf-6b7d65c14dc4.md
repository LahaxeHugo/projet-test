# Openload and Streamango close their doors

Année: 2019
Catégorie: Law 👨‍⚖️
Mois - Jour: 31 Octobre
État: Complet ✅

Openload and Streamango, two popular platforms, closed not because they wanted to, but because they had an agreement with Alliance for Creativity and Entertainment (ACE), a coalition that fights against piracy. They will also have to pay significant damages.
In itself, Openload has not come into existence to illegally offer movies and series. It was quite possible to post any type of videos so that they could be watched by anyone. But users have quickly put online movies and series and the platform was mainly known for this reason in recent years. The story is similar for Streamango. Both sites were linked.

src : [https://kulturegeek.fr/news-181331/streaming-films-series-openload-streamango-ferment-leurs-portes](https://kulturegeek.fr/news-181331/streaming-films-series-openload-streamango-ferment-leurs-portes)

![](Untitled-e6847996-940c-4b80-80ef-2690e662e3a3.png)