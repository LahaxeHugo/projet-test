# CompuServe became the first service to offer electronic mail capabilities and technical support to personal computer users

Année: 1970
Catégorie: Innovation 🎢

CompuServe was the first major commercial online service provider in the United States. It dominated the field during the 1980s and remained a major influence through the mid-1990s. At its peak in the early 1990s, CompuServe was known for its online chat system, message forums covering a variety of topics and extensive software libraries for most computer platforms. 

So we can considered CompuServe as the cradle of the mail's development.