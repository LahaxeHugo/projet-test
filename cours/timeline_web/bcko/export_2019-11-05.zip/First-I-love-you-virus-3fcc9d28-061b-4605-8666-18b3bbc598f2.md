# First "I love you" virus

Année: 2000
Catégorie: Hackers 👾
Credits: https://en.wikipedia.org/wiki/ILOVEYOU
Credits: https://www.buzzly.fr/le-web-a-25-ans-decouvrez-les-dates-qui-ont-marque-son-histoire.html
Mois - Jour: 4 Mai
État: Complet ✅

"I love you" is the name of a computer worm that first appeared on May 4 2000 and sent as an attachment to an email called "I love you". The email recipient believes that the attachment is a text file (Love-Letter-for-you.txt.vbs). By opening the file, the user triggers the execution of a program contained in the file. This program inflicts damage on the local machine, overwriting random types of files (including Office files, image files, and audio files; however after overwriting MP3 files the virus hides the file, scans the user's contact list and sends an email to all of those contacts containing the infected attachment, ensuring its reproduction. This worm was the first to use the credulity of users on such a large scale.

It has spread over four days on more than 3.1 million machines worldwide.

![](Untitled-3d10f89d-0ce8-47c4-8ee5-13b62624d177.png)