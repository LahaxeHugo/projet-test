# Facebook has more than 2 billion users

Année: 2017
Catégorie: Step
Mois - Jour: 27 Juin
État: Complet ✅

An astronomical figure, compared to the world population, estimated at 7.4 billion people. Concretely, an active user is a user who connects at least once a month to the largest social network in the world, launched in 2004 by Harvard student Mark Zuckerberg. In France, the most recent figures, from last month, show 33 million active users per month, 25 million per day.

src: [https://www.lemonde.fr/pixels/article/2017/06/27/facebook-passe-la-barre-des-2-milliards-d-utilisateurs_5152063_4408996.html](https://www.lemonde.fr/pixels/article/2017/06/27/facebook-passe-la-barre-des-2-milliards-d-utilisateurs_5152063_4408996.html)

![](Untitled-73fd3672-f5ff-4419-9456-5bbfb4efb168.png)