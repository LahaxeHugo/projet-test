# Facebook’s Mark Zuckerberg faces a US congressional hearing

Année: 2018
Catégorie: Law 👨‍⚖️
Mois - Jour: 10 Avril
État: Complet ✅

Mark Zuckerberg explained to two committees of the Senate (trade and justice) gathered for the occasion, on the case Cambridge Analytica. This company specializing in political influence is suspected of having recovered data from 87 million users of the social network without their knowledge.

src: [https://www.lemonde.fr/pixels/article/2018/04/11/facebook-sous-pression-des-senateurs-americains-mark-zuckerberg-fait-face_5283639_4408996.html](https://www.lemonde.fr/pixels/article/2018/04/11/facebook-sous-pression-des-senateurs-americains-mark-zuckerberg-fait-face_5283639_4408996.html)

![](Untitled-8975e6fd-c7db-4942-97da-6f4ecc476513.png)