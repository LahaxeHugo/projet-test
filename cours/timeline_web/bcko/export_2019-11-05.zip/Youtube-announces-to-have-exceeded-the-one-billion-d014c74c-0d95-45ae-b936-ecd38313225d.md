# Youtube announces to have exceeded the one billion hours of videos seen every day on its platform

Année: 2017
Catégorie: Step
Mois - Jour: Février
État: Complet ✅

One billion. This is the number of hours of video watched every day by users on YouTube, according to the figures announced by the platform on his blog. As stated by the daily Les Echos, this volume has been multiplied by ten since 2012, YouTube has since that year improved its recommendation algorithm.
Objective: to offer more targeted content likely to be more interesting to the user, and therefore to retain it on the platform.

src : [https://www.20minutes.fr/web/2022823-20170301-youtube-plus-milliard-heures-videos-visionnees-chaque-jour-internautes](https://www.20minutes.fr/web/2022823-20170301-youtube-plus-milliard-heures-videos-visionnees-chaque-jour-internautes)

![](Untitled-23c3d6db-2b45-4f49-95f1-8d69a71b9dee.png)