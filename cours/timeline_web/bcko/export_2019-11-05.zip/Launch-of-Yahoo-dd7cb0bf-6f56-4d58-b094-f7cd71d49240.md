# Launch of Yahoo

Année: 1994
Catégorie: Launch 🚀
Mois - Jour: Janvier

![](logo_yahoo-da03eb90-b3bf-4124-bd18-ba0f6dd1dea6.png)

The original Yahoo! company was founded by Jerry Yang and David Filo in January 1994.

In January 1994, Yang and Filo were electrical engineering graduate students at Stanford University, when they created a website named "Jerry and David's guide to the World Wide Web".

The site was a directory of other websites, organized in a hierarchy, as opposed to a searchable index of pages. In March 1994, "Jerry and David's Guide to the World Wide Web" was renamed "Yahoo!". The "[y](http://yahoo.com/)ahoo.com" domain was created on January 18, 1995.

Yahoo was one of the pioneers of the early Internet era in the 1990s.

[https://en.wikipedia.org/wiki/Yahoo](https://en.wikipedia.org/wiki/Yahoo)!

[https://logos.fandom.com/wiki/Yahoo](https://logos.fandom.com/wiki/Yahoo)!