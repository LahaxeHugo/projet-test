# Kaggle, a website that serves as a platform for machine learning competitions, is launched.

Année: 2010
Catégorie: Launch 🚀

