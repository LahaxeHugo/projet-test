# Creation of Uber Eats

Année: 2014
Catégorie: Launch 🚀
Credits: https://www.francebleu.fr/infos/economie-social/uber-eats-s-installe-au-mans-les-restaurateurs-sont-divises-1525279562
Credits: https://fr.wikipedia.org/wiki/Uber_Eats
Mois - Jour: Août
État: Complet ✅

Uber Eats is a delivery service for dishes cooked by partner restaurants created by the founders of Uber. It runs through a mobile app and a website, and is available in several countries around the world: North America, South America, Europe, Australia, Asia and some cities in Africa. Regarding France, the first city where Uber Eats was proposed is Paris in March 2016. In 2019, there is the presence of Uber Eats in more than 95 cities.

![](Untitled-ef11e1bb-29d4-4018-a529-9990489fb696.png)