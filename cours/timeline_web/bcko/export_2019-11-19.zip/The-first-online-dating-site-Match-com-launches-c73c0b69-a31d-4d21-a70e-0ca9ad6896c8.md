# The first online dating site, [Match.com](http://match.com/), launches.

Année: 1995
Catégorie: Launch 🚀
État: Complet ✅

![](matchlogo_blue_310x206-5f986f74-49ef-477c-ba6b-aa56eb3a6384.png)

[Match.com](http://match.com/) was founded by Gary Kremen and Peng T. Ong in 1993. Early on, Kremen was assisted by Ong, who helped in the design of the initial system, and Simon Glinsky, who served as the company's marketing consultant. Fran Maier joined the company as its director of marketing.

 According to a retrospective from The Atlantic, Maier helped to develop [Match.com](http://match.com/)'s initial business strategy, which included a subscription model and the inclusion of diverse communities, including women, technology professionals, and the lesbian, gay, bisexual, and transgender communities. [Match.com](http://match.com/) went live as a free beta in early 1995.

In 2011, A woman claiming she was raped by another person she met on [Match.com](http://match.com/) sued the site. The woman and her lawyer wanted [Match.com](http://match.com/) to start doing background checks on their users in order to prevent registered sex offenders from using the site. [Match.com](http://match.com/) has responded that it would create many problems trying to get background information from all their users. Days after the lawsuit was filed, [Match.com](http://match.com/) announced that the site would begin screening new members.