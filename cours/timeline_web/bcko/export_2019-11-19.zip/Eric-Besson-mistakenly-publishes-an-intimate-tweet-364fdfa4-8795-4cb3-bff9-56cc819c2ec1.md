# Eric Besson mistakenly publishes an intimate tweet. One of the most famous facts of the microblogging service in France

Année: 2011
Catégorie: Publishing 📚
Mois - Jour: 19 Octobre

"When I get home I go to bed, too tired, with you?" This is a sweet little innocent word that any surfer could send but that takes a whole other dimension when it is sent on Twitter by a minister. In this case, that of the Digital Economy, Eric Besson, a great regular in the social network. The Internet immediately seized history and hastened to taunt the minister, who did not hesitate to answer.
Eric Besson was quick to explain his blunder. "LOL and excuses, it will teach me to manipulate the list of drafts and to press the send key by mistake, I do not go to bed ...", he wrote a few minutes later. Explanations that do not seem to convince Internet users.
The minister, somewhat annoyed by these mockery, eventually cut short by writing: "Okay I'll leave you to your delusions.I have a hearing at the National Assembly to prepare"

src: [https://www.europe1.fr/medias-tele/Eric-Besson-gaffe-sur-Twitter-339696](https://www.europe1.fr/medias-tele/Eric-Besson-gaffe-sur-Twitter-339696)