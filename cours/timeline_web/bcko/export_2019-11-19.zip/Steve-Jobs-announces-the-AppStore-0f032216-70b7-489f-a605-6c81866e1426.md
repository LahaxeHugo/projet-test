# Steve Jobs announces the AppStore

Année: 2008
Catégorie: Announcement

