# The million dollar Homepage

Année: 2005
Catégorie: Launch 🚀
Credits: https://www.taschen.com/pages/en/catalogue/graphic_design/all/04690/facts.web_design_the_evolution_of_the_digital_world_1990today.htm#images_gallery-5
Mois - Jour: 26 Août
État: Complet ✅

The Million Dollar Homepage is a website created in 2005 by Alex Tew, studying at Wiltshire England, to gain money to pay his degree studies.

The homepage contained 1 million pixels that were sold 1$ each as an advertising space. People had to by at least a square of 10x10 and then buyers had to place their images linked to a URL.

The goal was to sell every pixel so that Alex can collect 1 million $.

The website quickly became a true phenomenon and the last thousand of pixels were put on eBay on January 1st 2006 and sold 38 100$. The whole website was sold for 1 037 100$.

[http://www.milliondollarhomepage.com/](http://www.milliondollarhomepage.com/)

![](Untitled-7bd3bf40-f469-4c73-9b43-cd09a9360f68.png)