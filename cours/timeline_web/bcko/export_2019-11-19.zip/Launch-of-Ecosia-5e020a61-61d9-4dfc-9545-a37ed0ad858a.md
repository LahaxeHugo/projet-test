# Launch of Ecosia

Année: 2009
Catégorie: Launch 🚀
Mois - Jour: 7 Décembre
État: Complet ✅

Ecosia is a German search engine that pays 80% of its profits to a reforestation program present around the world. It plants trees in Burkina Faso, Peru, Tanzania, Madagascar and twelve other countries.

The company, certified B corporation, works with different partners including WeForest and OZG in Burkina Faso, PUR Projet in Peru and Eden Projects in Madagascar.

Since February 2019, more than 50 million trees had been planted since its creation, representing a total of several billion searches, with an average of 45 searches to plant a tree.

src: [https://fr.wikipedia.org/wiki/Ecosia](https://fr.wikipedia.org/wiki/Ecosia)

![](Untitled-57159ea4-e21f-47f1-9295-d6978392b6b1.png)