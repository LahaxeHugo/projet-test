# a billion active Internet users on the month (according to Comscore)

Année: 2008
Catégorie: Step
Mois - Jour: Décembre

