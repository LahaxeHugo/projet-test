# Google Chrome becomes the most used browser in the world (according to Statcounter)

Année: 2012
Catégorie: Step
Mois - Jour: Juin

