# A coffee maker becomes the heroine of the first webcam

Année: 1993
Catégorie: Innovation 🎢
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html
Mois - Jour: Novembre
État: Complet ✅

Technology at the service of humanity: To find out if coffee is ready, researchers at the computer lab at the University of Cambridge point a camera at the building's coffee machine, which sends, three times a minute, an image of the object. They decided to put it on the Web in 1993 and is often considered as the first webcam.

![](Untitled-a07999c8-5186-4b76-bb2d-09b14ea98c48.png)