# Google develop his first algorithm: Caffeine

Année: 2010
Catégorie: Launch 🚀
État: Complet ✅

![](google-caffeine-update-760x400-a3174df7-8dc4-4108-96ba-3eb66a812238.png)

Deployed in June 2010, Caffeine is a redesign of Google's indexing system. The Caffeine algorithm allows you to crawl and then index a page instantly.

Before the implementation of this algorithm, Google could not index a set of pages, after extracting, analyzing and understanding its contents.

With this new system that makes it quick and easy to index, Google is now able to provide 50% more content and articles in its search results than before the algorithm was implemented.

[https://blog.hubspot.fr/marketing/algorithmes-google](https://blog.hubspot.fr/marketing/algorithmes-google)