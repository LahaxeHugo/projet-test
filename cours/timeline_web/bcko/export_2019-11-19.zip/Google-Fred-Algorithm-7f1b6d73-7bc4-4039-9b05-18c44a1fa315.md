# Google Fred Algorithm

Année: 2017
Catégorie: Launch 🚀
Credits: image: https://expresswriters.com/google-fred-and-how-it-affects-your-content/
Credits: https://www.pixalione.fr/glossaire/algorithmes-de-recherche-le-cas-de-google/
Mois - Jour: Mars
État: Complet ✅

![](google_fred-9df6a794-826e-4b66-8051-61b28b9c72f9.jpg)

Active since 2017, Google Fred is an algorithm update that targets black-hat tactics tied to aggressive monetization. This includes an overload on ads, low-value content, and little added user benefits.

This doesn't mean all sites hit by the Google Fred update are dummy sites created for ad revenue, but the majority of websites affected were content sites that have a large amount of ads and seem to have been created for the purpose of generating revenue over solving a user's problem.

Unlike penguin, Fred's primary goal is the "purification" by google of sites with low added value.