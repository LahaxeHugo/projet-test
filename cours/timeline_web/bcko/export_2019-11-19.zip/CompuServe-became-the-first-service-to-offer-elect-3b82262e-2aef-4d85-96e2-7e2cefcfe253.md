# CompuServe became the first service to offer electronic mail capabilities

Année: 1970
Catégorie: Innovation 🎢
Credits: image: http://www.astrosurf.com/luxorion/compuserve-histoire.htm
Credits: https://www.compuserve.com/home/about.jsp
État: Complet ✅

![](compuserve-v3fr-493ceb5b-28c9-4879-9e88-8af5899d998c.jpg)

CompuServe became the first service to offer electronic mail capabilities and technical support to personal computer users.

CompuServe was the first major commercial online service provider in the United States. It dominated the field during the 1980s and remained a major influence through the mid-1990s. At its peak in the early 1990s, CompuServe was known for its online chat system, message forums covering a variety of topics and extensive software libraries for most computer platforms. 

So we can considered CompuServe as the cradle of the mail's development.