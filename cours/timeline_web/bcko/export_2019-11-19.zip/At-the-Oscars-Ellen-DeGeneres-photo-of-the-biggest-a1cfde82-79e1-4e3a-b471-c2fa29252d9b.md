# At the Oscars, Ellen DeGeneres' photo of the biggest stars was retweeted more than 2 million times on Twitter, becoming the most shared tweet in history

Année: 2014
Catégorie: Step
Mois - Jour: 2 Mars
État: Complet ✅

Actress Ellen DeGeneres encouraged the public to immediately broadcast this photo with the declared goal of breaking the record.
The selfie on which the stars of Hollywood, with Kevin Spacey, Jennifer Lawrence, Jared Leto, Lupita Nyongo'o and her brother, Bradley Cooper, Channing Tatum, Angelina Jolie as a bonus, have fun like kids, made Twitter waver a few moments and had been retweeted more than 2 million times in less than two hours later.

src : [https://www.huffingtonpost.fr/2014/03/03/oscars-selfie-ellen-degeneres-rt-twitter-record_n_4887974.html](https://www.huffingtonpost.fr/2014/03/03/oscars-selfie-ellen-degeneres-rt-twitter-record_n_4887974.html)

![](Untitled-405c681e-5585-4409-bfc3-3720986fff12.png)