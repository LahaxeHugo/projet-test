# Launch of Twitch

Année: 2011
Catégorie: Launch 🚀
Credits: https://blog.twitch.tv/en/2019/03/29/twitch-for-game-developers-b664163bed65/
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html
Mois - Jour: 6 Juin
État: Complet ✅

Originally called [Justin.tv](http://justin.tv/), this streaming site is now mainly used to broadcast games of live video games. Extremely popular, especially among teenagers and young adults, it is bought in 2014 by Amazon and continues, still today, its rise. In February 2019, French ministers came to bring the ideas of the government in the framework of the great national debate wanted by Emmanuel Macron.

![](Untitled-0bb24891-92f0-4fc6-ab95-085e34ce02e7.png)