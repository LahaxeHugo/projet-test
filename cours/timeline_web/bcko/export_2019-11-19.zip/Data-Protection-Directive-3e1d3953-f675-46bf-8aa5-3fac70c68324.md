# Data Protection Directive

Année: 1995
Catégorie: Law 👨‍⚖️
Credits: https://thehistoryoftheweb.com/timeline/?date_from=all
Mois - Jour: 24 October
État: Complet ✅

One of the first pieces of legislation passed internationally regarding privacy online, the Data Protection Directive provides protections for individuals with regard to data collection online. It restricts the unnecessary collection of personal data, and requires sites to make clear exactly what data will be tracked. It was superseded in 2018 by the General Data Protection Regulation.