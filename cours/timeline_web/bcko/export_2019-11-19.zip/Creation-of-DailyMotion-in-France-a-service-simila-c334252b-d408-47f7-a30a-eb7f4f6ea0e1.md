# Creation of DailyMotion in France, a service similar to YouTube.

Année: 2005
Catégorie: Launch 🚀
Mois - Jour: 15 Mars

