# Creation of Airbnb

Année: 2008
Catégorie: Launch 🚀
Credits: https://www.tourmag.com/Qui-pourra-stopper-l-expansion-d-Airbnb_a91227.html
Credits: https://fr.wikipedia.org/wiki/Airbnb
Mois - Jour: Août
État: Complet ✅

Airbnb is a paid community residential rental and booking platform founded in 2008 by Americans Brian Chesky, Joe Gebbia and Nathan Blecharczyk. The website contains in 2015 more than 1.5 million ads in 34,000 cities and 192 countries. Headquartered in San Francisco, the company is owned and operated by Airbnb Inc. From inception in August 2008 until June 2012, more than 10 million nights were booked on Airbnb. Since Thursday, November 17, 2016, Brian Chesky presented the new services offered by Airbnb: experiences and places. For the experiments, the inhabitants share their social life, their interests and work at a price. And as far as the places are concerned, expert guides, knowing the places well, propose addresses of recommended places according to specific criteria.

![](Untitled-184e6635-5064-4478-9bf0-c45d2c5d2f1c.png)