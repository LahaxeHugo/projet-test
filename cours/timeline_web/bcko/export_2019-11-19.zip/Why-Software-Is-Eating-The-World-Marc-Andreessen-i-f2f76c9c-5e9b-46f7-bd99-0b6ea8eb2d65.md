# Why Software Is Eating The World,
Marc Andreessen in the Wall Street Journal

Année: 2011
Catégorie: Publishing 📚
Mois - Jour: 20 Septembre

