# Launch of Internet Archive

Année: 1996
Catégorie: Launch 🚀
Credits: https://www.theverge.com/2015/10/22/9593656/internet-archive-wayback-machine-redesign-announced
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html
Mois - Jour: Octobre
État: Complet ✅

The American Brewster Kahle launches the aptly named Internet Archive Foundation, with a project as clear as it is ambitious: to archive the Web. Today, it is possible to return to the past of the Web, thanks to the precious Wayback Machine, its machine to go back in time.

![](Untitled-84e36d32-91dd-445e-9c9c-f0e205c7eef3.png)