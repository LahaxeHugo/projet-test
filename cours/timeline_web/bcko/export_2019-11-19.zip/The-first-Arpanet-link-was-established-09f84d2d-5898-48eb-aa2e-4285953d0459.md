# The first Arpanet link was established

Année: 1969
Catégorie: Announcement,Innovation 🎢
Credits: image: https://stemchildrensbooks.com/october-29-1969-the-first-computer-to-computer-link-was-established-on-arpanet/
Credits: https://www.edn.com/electronics-blogs/edn-moments/4399541/ARPANET-establishes-1st-computer-to-computer-link--October-29--1969
Mois - Jour: 29 Octobre
État: Complet ✅

![](arpanet-1d2d07c8-071b-4135-a4ff-5c692a5fa295.jpg)

The first Arpanet link was established between the University of California, Los Angeles (UCLA) and the Stanford Research Institute at 22:30 hours.

The message text was meant to be the word “login,” but only the L and O were transmitted before the system crashed. About an hour after the crash, the system was recovered and a full “login” message was sent as the second transmission.

The Advanced Research Projects Agency Network (ARPANET) was an early packet-switching network and the first network to implement the TCP/IP protocol suite. Both technologies became the technical foundation of the Internet. It marked the start of a new era.