# "Cyberspace. A consensual hallucination..." The Neuromancer by William Gibson

Année: 1984
Catégorie: Publishing 📚
Credits: image: https://en.wikipedia.org/wiki/Neuromancer
Credits: [https://www.theguardian.com/books/2014/jul/28/william-gibson-neuromancer-cyberpunk-books](https://www.theguardian.com/books/2014/jul/28/william-gibson-neuromancer-cyberpunk-books)
Mois - Jour: 1er Juillet
État: Complet ✅

![](Neuromancer_livre-492ad511-bfe7-40b5-b328-4283f8b5a52b.jpg)

In Neuromancer, published 30 years ago this month, Gibson popularized the idea of ​​cyberspace: a "consensual hallucination" created by millions of connected computers.

On its release, Neuromancer won the "big three" for science fiction: the Nebula, Philip K Dick and Hugo awards. It sold more than 6m copies and launched an entire aesthetic: cyberpunk. In predicting this future, Gibson can be said to have helped shape our conception of the internet.