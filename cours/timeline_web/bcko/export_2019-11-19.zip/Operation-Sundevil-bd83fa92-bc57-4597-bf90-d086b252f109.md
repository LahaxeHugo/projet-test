# Operation Sundevil

Année: 1990
Catégorie: Hackers 👾
Credits: http://www.mit.edu/hacker/part3.html
Mois - Jour: 1er Janvier
État: Complet ✅

Operation Sundevil was a 1990 nationwide United States Secret Service crackdown on "illegal computer hacking activities." It involved raids in approximately fifteen different cities and resulted in three arrests and the confiscation of computers, the contents of electronic bulletin board systems (BBSes), and floppy disks.

The several arrests and trials conducted to the creation of the Electronic Frontier Foundation : 

[Creation of the Electronic Frontier Foundation (EFF)](./Creation-of-the-Electronic-Frontier-Foundation-EFF-fe5a12fc-8966-4918-872b-44de5893593e.md)

Operation Sundevil is also considered as one of the preliminary attacks against "Legion of Doom" and inspired Bruce Sterling for the release of "The Hacker Crackdown".

![](Untitled-20e8399a-df6d-4edd-a438-8390a5881afc.png)