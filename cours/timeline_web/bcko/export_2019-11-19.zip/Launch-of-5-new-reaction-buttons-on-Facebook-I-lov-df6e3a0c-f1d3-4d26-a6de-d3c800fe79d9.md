# Launch of 5 new reaction buttons on Facebook: "I love", "Haha", "Wow", "Sad" and "Grrr"

Année: 2016
Catégorie: Launch 🚀
Credits: https://www.journaldugeek.com/2016/02/24/reactions-facebook/
Credits: https://www.agenceecofin.com/reseaux-sociaux/2502-36171-facebook-a-lance-les-boutons-j-adore-ha-ha-wouah-grrr-et-triste
Mois - Jour: 24 Février
État: Complet ✅

On Facebook, there is no longer just the "Like" button to translate reactions to posts. Since February 24, 2016, the social network offers 5 new buttons to express other feelings.

By hovering over the "Like" button, the user will see several icons to show a more precise and better response to the situation. It thus becomes possible to associate the "I like" with a heart to say "I love". There are also smileys. One for laughing ("Haha"). The other is taken aback ("wow"). The 3rd cry ("Sad"). The last one expresses anger ("Grrr").

This new offer is the result of studies that the Facebook team has been conducting for a year. The tests began on October 8, 2015. The update will be done gradually. It's about responding to a request that had become urgent. Hundreds of pages and groups of Internet users wanted to say "I do not like".

Facebook had to find the right balance, because Mark Zuckerberg, the boss of the social network, did not fail to recall that with the button "I do not like", the platform is transformed into "a forum where people vote for or against people's publications ". The very popular social network might lose its attractiveness.

![](Untitled-cd4615ac-516f-4143-ac39-1e7c7cd10b8a.png)