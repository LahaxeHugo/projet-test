# Creation of the Electronic Frontier Foundation (EFF)

Année: 1990
Catégorie: Law 👨‍⚖️
Credits: image: https://smartmonkeywebworks.com/electronic-frontier-foundation-nov-17-featured-non-profit/
Credits: https://www.eff.org/fr/about/history
Mois - Jour: 1er Juillet
État: Complet ✅

Created by Mitch Kapor (Lotus Notes), John Gilmore, and John Perry Barlow, of the Electronic Frontier Foundation (EFF) to guarantee the respect of freedom of expression and information in the cyberespace.

The Electronic Frontier Foundation was formed in July 1990 by John Gilmore, John Perry Barlow and Mitch Kapor in response to a series of actions by law enforcement agencies that led them to conclude that the authorities were gravely uninformed about emerging forms of online communication, and that there was a need for increased protection for Internet civil liberties.

Somehow, the several arrests and trials during Operation Sundevil in 1990 (a nationwide United States Secret Service crackdown on "illegal computer hacking activities.") conducted to the creation of the Electronic Frontier Foundation in July 1990.