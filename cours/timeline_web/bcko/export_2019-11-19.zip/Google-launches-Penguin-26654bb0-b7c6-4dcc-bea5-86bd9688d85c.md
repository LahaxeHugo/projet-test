# Google launches Penguin

Année: 2012
Catégorie: Launch 🚀
Credits: image: https://www.webmarketing-com.com/2013/05/23/21551-google-penguin-4-est-sorti-dans-la-nuit
Credits: https://fr.wikipedia.org/wiki/Penguin_(Google)
Mois - Jour: 24 Avril
État: Complet ✅

![](google-penguin1-6488a41e-6c79-47d3-b537-c01fe7003b5f.jpg)

Google Penguin is a codename for a Google algorithm update that was first announced on April 24, 2012. 

The update was aimed at decreasing search engine rankings of websites that violate Google's Webmaster Guidelines by using now declared black-hat SEO techniques involved in increasing artificially the ranking of a webpage by manipulating the number of links pointing to the page.

The Penguin algorithm is the bane of webmasters, each update was very strongly discussed on the web and caused waves of panic and questioning on social networks. 

Experts will be able to confirm, with each fluctuation of the SERP, the SEO community was panicking fearing a new update of the algorithm.