# Launch of DeviantArt

Année: 2000
Catégorie: Launch 🚀
Credits: https://www.taschen.com/pages/en/catalogue/graphic_design/all/04690/facts.web_design_the_evolution_of_the_digital_world_1990today.htm#images_gallery-5
Mois - Jour: 7 Août
État: Complet ✅

DeviantArt is an online artistic community featuring artwork, videography and photography, where everyone could publish and show his own creations. On August 2015, (15th anniversary) the website registered more than 36 millions of people, and more than 200 millions of publications.

This website allowed professionals to share their work to the world and use the website as a portfolio, but also permitted amateurs to publish and follow people on the platform.

Today, we can find similar websites such as Behance, Dribbble or Awwwards, where people exchange, rate, and share about their creations on the web.

![](Untitled-6466e8c9-b2cc-451f-93c3-a5c9f0f7668a.png)