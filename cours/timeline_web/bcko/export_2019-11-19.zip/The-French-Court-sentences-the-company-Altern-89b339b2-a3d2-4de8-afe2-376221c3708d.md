# The French Court sentences the company Altern

Année: 1999
Catégorie: Law 👨‍⚖️
Credits: https://www.liberation.fr/ecrans/1999/02/26/altern-le-debat-est-la-reactions-des-lecteurs-apres-la-condamnation-du-fournisseur-d-hebergement_266043
Mois - Jour: 10 Février

The French Court sentences the company Altern for hosting, among thousands of others, a site broadcasting photos of Estelle Hallyday nudes. This event provoked a wide debate on responsibility and freedom of expression on the Web.