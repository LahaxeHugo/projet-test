# Instragam takeaway by Facebook

Année: 2012
Catégorie: Acquisition 💰
Mois - Jour: 22 août 
État: Complet ✅

Intagram has managed to acquire nearly 30 million mobile users. The mobile will be in the coming years, the favorite medium for surfing the Internet and thanks to Instagram, Facebook is repositioning itself on this sector.
Facebook will soon go public and even if there is no real doubt that the world's largest social network will have the ability to attract investors. However, this takeover of Instagram, to say the least unexpected, has the effect of drawing attention to Facebook and indirectly creates more value.
Facebook is facing more and more competitors (Twitter, Pinterest) and one of the most threatening: Google. Even though Google + is not yet successful. The purchase of Instagram could have been the work of the search engine.
Facebook has remained very close to the release version of its features. Facebook innovates little. Only novelty to put in the tooth in recent years: the Timeline. As a result, the two creators will stay in place and integrate the "Facebook Group" which will bring new blood to Facebook.
Instagram is a "cool" application that brings together "cool" users so one of the reasons for the buyout is probably to improve its brand image.

src: [https://blog-fr.orson.io/reseaux-sociaux/facebook-rachete-instagram](https://blog-fr.orson.io/reseaux-sociaux/facebook-rachete-instagram)

![](Untitled-e86cb0be-4145-4c62-a944-08153f50ed78.png)