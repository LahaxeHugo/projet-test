# Skype creation

Année: 2003
Catégorie: Launch 🚀
Credits: https://www.tiki-toki.com/timeline/entry/137139/Chronologie-du-rseau-internet/#vars!date=1980-01-17_07:10:30!
Mois - Jour: Août
État: Complet ✅

Janus Friis and Niklas Zennström decided to launch Skype, a free software that allows free screen sharing and free phone or video calls to computers anywhere in the world. This innovation revolutionises the way that people and companies communicate together while mobile phone calls were still chargeable.

Several functionalities such as instant messaging, file sharing and videoconferencing were also added to the software that changed forever the way that professionals and individuals communicate together.

![](Untitled-599a515e-328b-4460-ae77-5375dbe15e02.png)