# Birth of the World Wide Web

Année: 1989
Catégorie: Launch 🚀
Credits: https://disenowebakus.net/en/world-wide-web
Credits: https://www.buzzly.fr/le-web-a-25-ans-decouvrez-les-dates-qui-ont-marque-son-histoire.html
Mois - Jour: 13 Mars
État: Complet ✅

Tim Berners-Lee, who was hired at CERN in Geneva in 1984 to work on data acquisition and processing, proposes to develop a web-based hypertext system to improve the dissemination of internal information: "Information Management: A Proposal ". He is the inventor of the first Web server he calls "httpd" and the first Web client he calls "WWW" for the World Wide Web.

![](Untitled-3eb769aa-92bb-4ada-9656-c179d3fa8962.png)