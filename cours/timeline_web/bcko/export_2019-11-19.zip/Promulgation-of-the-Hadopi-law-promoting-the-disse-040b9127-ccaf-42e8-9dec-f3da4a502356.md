# Promulgation of the Hadopi law, "promoting the dissemination and protection of creation on the internet"

Année: 2009
Catégorie: Law 👨‍⚖️
Credits: https://www.lemonde.fr/les-decodeurs/article/2018/08/14/hadopi-beaucoup-d-avertissements-mais-peu-de-condamnations_5342325_4355770.html
Credits: https://fr.wikipedia.org/wiki/Loi_favorisant_la_diffusion_et_la_protection_de_la_cr%C3%A9ation_sur_internet
Mois - Jour: 12 Juin
État: Complet ✅

It is the law n ° 2009-669 of June 12th, 2009 favoring the diffusion and the protection of the creation on Internet, known as law Hadopi 1 or law creation and Internet is a French law which aims mainly to put an end to the partitions of peer-to-peer files when such sharing is in violation of copyright law. This law has six chapters and two components: the graduated response component and the legal supply enhancement component. Recidivism is increasingly punished and the legislator speaks of "graduated response". This law created the High Authority for the Dissemination of Works and the Protection of Rights on the Internet (Hadopi), an independent French regulatory body, and then supplemented by the Hadopi 2 law of 31 December 2009.

![](Untitled-4c041c7b-06ba-48c5-9fb9-ce1f5c365876.png)