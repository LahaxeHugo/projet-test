# Google releases his new algorithm: Pirate

Année: 2012
Catégorie: Launch 🚀
Credits: image : https://www.julien-muller.fr/2012/08/14/google-la-revolution-de-lalgorithme-est-en-marche-encore/
Credits: https://blog.hubspot.fr/marketing/algorithmes-google
Mois - Jour: Août 
État: Complet ✅

![](google_pirate-4c6bf02c-00b1-4de6-81ff-eb65dfc52cd6.jpg)

The Pirate algorithm is a search filter, deployed in August 2012. It aims to remove pages from search results, sites that have received complaints of copyright infringement, sent via Google's DMCA system.

This filter is updated regularly to remove pages that offer illegal downloading of movies, series or music.