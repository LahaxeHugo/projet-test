# Google Pigeon Algorithm

Année: 2014
Catégorie: Launch 🚀
Credits: image : https://www.searchenginejournal.com/google-algorithm-history/pigeon-update/
Credits: https://blog.hubspot.fr/marketing/algorithmes-google
Mois - Jour: Juillet
État: Complet ✅

![](google-pigeon-update-760x400-1ea6bfb7-ff8d-4e41-a60c-774db77a6119.png)

The Pigeon algorithm was deployed in July 2014, in the United States and in June 2015 internationally. 

Encouraging geographic search thanks to the geographical location of the websites, this algorithm favors local search results to provide more accurate solutions to user queries. The changes made by this algorithm are visible on Google and Google Maps.

The Pigeon algorithm had an impact especially on local businesses and businesses such as restaurants, bars or doctors' offices.