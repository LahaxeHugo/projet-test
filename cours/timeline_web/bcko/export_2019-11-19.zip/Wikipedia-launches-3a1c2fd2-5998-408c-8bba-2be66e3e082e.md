# Wikipedia launches

Année: 2001
Catégorie: Launch 🚀
Credits: https://en.wikipedia.org/wiki/History_of_Wikipedia
Mois - Jour: 15 Janvier
État: Complet ✅

Wikipedia is a multilingual online encyclopedia created and maintained as an open collaboration project using a wiki-based editing system. It is the largest and most popular general reference work on the World Wide Web.  
Wikipedia features exclusively free content and no commercial ads, and changed forever the way that people have access to information.

![](Untitled-36b09b75-0bb4-4a99-8d5d-703a1c2c7b40.png)