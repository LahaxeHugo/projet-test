# CompuServe became the first service to offer electronic mail capabilities

Année: 1970
Catégorie: Innovation 🎢
Credits: image: http://www.astrosurf.com/luxorion/compuserve-histoire.htm
Credits: https://www.compuserve.com/home/about.jsp
État: Complet ✅

![CompuServe%20became%20the%20first%20service%20to%20offer%20elect/compuserve-v3fr.jpg](CompuServe%20became%20the%20first%20service%20to%20offer%20elect/compuserve-v3fr.jpg)

CompuServe became the first service to offer electronic mail capabilities and technical support to personal computer users.

CompuServe was the first major commercial online service provider in the United States. It dominated the field during the 1980s and remained a major influence through the mid-1990s. At its peak in the early 1990s, CompuServe was known for its online chat system, message forums covering a variety of topics and extensive software libraries for most computer platforms. 

So we can considered CompuServe as the cradle of the mail's development.