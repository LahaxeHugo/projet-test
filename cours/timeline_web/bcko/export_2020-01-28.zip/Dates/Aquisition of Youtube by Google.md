# Aquisition of Youtube by Google

Année: 2006
Catégorie: Acquisition 💰
Mois - Jour: 9 Octobre