# Launch of Amazon

Année: 1994
Catégorie: Launch 🚀
Credits: https://www.businessinsider.com/jeff-bezos-amazon-history-facts-2017-4?IR=T]
Mois - Jour: 5 Juillet
État: Complet ✅

![Launch%20of%20Amazon/amazon.png](Launch%20of%20Amazon/amazon.png)

The company was founded as a result of what Jeff Bezos called his "regret minimization framework", which described his efforts to fend off any regrets for not participating sooner in the Internet business boom during that time.

 In 1994, Bezos left his employment as vice-president of D. E. Shaw & Co, a Wall Street firm, and moved to Seattle, Washington, where he began to work on a business plan for what would become [Amazon.com](http://amazon.com/).

Amazon starts off as an online bookstore selling books, primarily competing with local booksellers and Barnes & Noble. It IPOs in 1997.

Bezos selected the name Amazon by looking through the dictionary, he settled on "Amazon" because it was a place that was "exotic and different", just as he had envisioned for his Internet enterprise.