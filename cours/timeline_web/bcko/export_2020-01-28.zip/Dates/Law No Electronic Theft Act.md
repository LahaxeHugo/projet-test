# Law : No Electronic Theft Act

Année: 1997
Catégorie: Law 👨‍⚖️
Credits: https://www.tiki-toki.com/timeline/entry/137139/Chronologie-du-rseau-internet/#vars!date=1966-02-23_12:57:30!
État: Complet ✅

The United States No Electronic Theft Act (NET Act) is a federal law passed in 1997, provides for criminal prosecution of individuals who engage in copyright infringement under certain circumstances, even when there is no monetary profit or commercial benefit from the infringement. 

The NET Act is applicable in situations such as running a file sharing application with outgoing transfers enabled, hosting files on a web account, transferring files through IRC, and other methods of making copyrighted material available over networks.