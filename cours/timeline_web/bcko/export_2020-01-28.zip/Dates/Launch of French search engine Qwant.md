# Launch of French search engine Qwant

Année: 2013
Catégorie: Navigation/Search Engine
Credits: https://www.ladepeche.fr/article/2018/11/04/2900254-faut-abandonner-google-moteur-recherche-francais-qwant.html
Credits: https://fr.wikipedia.org/wiki/Qwant
Mois - Jour: 16 Février
État: Complet ✅

Qwant is a French search engine. Launched on February 16, 2013 in beta version, then launched in final version on July 4, 2013, it announces since its launch not to trace its users, nor to sell their personal data, in order to guarantee their privacy and wants to be neutral in the display. results.

![Launch%20of%20French%20search%20engine%20Qwant/Untitled.png](Launch%20of%20French%20search%20engine%20Qwant/Untitled.png)