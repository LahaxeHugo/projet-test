# The first emoticon

Année: 1979
Catégorie: Innovation 🎢
État: Complet ✅

The first emoticon is not very young since it was invented in 1979 by Kevin Mackenzie in its form -).

The best known are obviously :) or ;-).

It is commonly accepted that they were invented in 1982 by computer scientist Scott Fahlamn at Carnegie Mellon University. Emoticons allowed to differentiate serious content and lighter. They are a contraction of "emotion icon".

src: https://www.blogdumoderateur.com/10-anecdotes-sur-internet/

![The%20first%20emoticon/Untitled.png](The%20first%20emoticon/Untitled.png)