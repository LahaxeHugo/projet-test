# Launch of Vue.js

Année: 2014
Catégorie: Launch 🚀
Mois - Jour: 11 Février

Evan You launches Vue.js, a web framework for building single page applications. Like other frameworks, it makes use of data binding, the model-view-controller pattern and client-side routing. But Vue is broken up into modules, so that developers could use whatever piece of the framework they want.