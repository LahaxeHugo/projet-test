# MP3 patented

Année: 1989
Catégorie: Law 👨‍⚖️
Mois - Jour: Avril
État: Complet ✅

MP3 is probably the most common format for music on the Internet, and has been hugely popular for over a decade. It fuelled the digital music revolution, it's the codec behind YouTube videos, it saturates P2P networks and it's now the must-use format for DRM-free digital music downloads. This ancient patent marked its public arrival.

src: https://www.cnet.com/news/the-50-most-significant-moments-of-internet-history/

![MP3%20patented/Untitled.png](MP3%20patented/Untitled.png)