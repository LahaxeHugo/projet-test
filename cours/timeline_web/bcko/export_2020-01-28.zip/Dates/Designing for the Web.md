# Designing for the Web

Année: 1996
Catégorie: Publishing 📚
Credits: https://thehistoryoftheweb.com/timeline/?date_from=all
Mois - Jour: 8 Janvier
État: Complet ✅

Designing for the Web: Getting Started in a New Medium

Jennifer Niederst writes Designing for the Web,her first foray into publishing and one of the first books about web design ever published. The book targets print and graphic designers looking to make the leap to the web, and provides all of the tools and techniques necessary to make that transition possible.