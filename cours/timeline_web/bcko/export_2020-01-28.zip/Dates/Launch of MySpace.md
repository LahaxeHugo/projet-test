# Launch of MySpace

Année: 2003
Catégorie: Launch 🚀
Credits: https://www.cbsnews.com/pictures/then-and-now-a-history-of-social-networking-sites/7/
Mois - Jour: 10 Août
État: Complet ✅

In August 2003, MySpace is a social networking service founded by several employees from the Internet marketing firm eUniverse such as Brad Greenspan, Chris DeWolfe, Josh Berman and Tom Anderson. 
The social network gave people access to a personalized web space to present diverse personal informations. It also hosted several music pages to upload their art.

MySpace became famous in the mid-2000s and allowed several musical contributors to reach a huge renown. The social network is so famous in the music world that Music Groups prefer creating a MySpace page instead of a dedicated Website.

In that case, in changed forever the way that artists communicate with their audience about dates and tours. It's easier than ever.

It even became the n°1 website in 2006 and valued $12 billion in 2007. However, MySpace's popularity started to decreased in the end of the 2000s, due to the emersion of other social networks like Facebook. 

![Launch%20of%20MySpace/Untitled.png](Launch%20of%20MySpace/Untitled.png)