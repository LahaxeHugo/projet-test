# The Dancing Baby, a 3D animation, becomes one of the first viral videos.

Année: 1996
Catégorie: Images on the web 🖼
Credits: https://www.youtube.com/watch?time_continue=11&v=_9nh6QoUsVU

[https://www.youtube.com/watch?time_continue=11&v=_9nh6QoUsVU](https://www.youtube.com/watch?time_continue=11&v=_9nh6QoUsVU)