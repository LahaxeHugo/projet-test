# First Launch of Mosaic web browser

Année: 1993
Catégorie: Launch 🚀
Credits: [http://scihi.org/ncsa-mosaic-web/](http://scihi.org/ncsa-mosaic-web/)
Credits: https://www.wiselyguide.com/mosaic-first-web-browser-25-years-old/
Mois - Jour: 5 Janvier
État: Complet ✅

![First%20Launch%20of%20Mosaic%20web%20browser/mosaic_logo.jpg](First%20Launch%20of%20Mosaic%20web%20browser/mosaic_logo.jpg)

On April 22, 1993, version 1.0 Mosaic, was released, the web browser credited with popularizing the World Wide Web. 

It was the first Web browser as we know today with a graphical user interface enabling an interactive easy to use browsing experience. And without graphics the Web as we know it today would not exist.

Mosaic was the web browser that led to the Internet boom of the 1990s.