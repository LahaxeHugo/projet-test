# Image : On the internet, nobody knows your a dog

Année: 1993
Catégorie: Images on the web 🖼
Credits: https://www.nouvelobs.com/rue89/rue89-ce-qui-nous-arrive-sur-la-toile/20131125.RUE0429/sur-internet-tout-le-monde-sait-que-tu-es-un-chien-et-raciste-en-plus.html
Mois - Jour: 5 Juillet
État: Complet ✅

« On the Internet, nobody knows you're a dog » is an adage from a press drawing, created by Peter Steiner in the New Yorker of July 5.
This drawing symbolizes an approach of private life on internet, and highlights the fact that users can send and receive messages in total anonymity.

Moreover, if anonymity was a thing during the 80s, the web came to life in the mid-2000s when a massive phenomenon of personalization emerged thanks to social networks.

![Image%20On%20the%20internet%20nobody%20knows%20your%20a%20dog/Untitled.png](Image%20On%20the%20internet%20nobody%20knows%20your%20a%20dog/Untitled.png)