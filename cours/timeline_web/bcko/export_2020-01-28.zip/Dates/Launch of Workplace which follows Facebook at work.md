# Launch of Workplace, which follows Facebook at work in the corporate social media market

Année: 2016
Catégorie: Launch 🚀
Mois - Jour: octobre
État: Complet ✅

Facebook announced on Monday that its Workplace by Facebook service (formerly Facebook at Work) will now be open to all companies worldwide, after having reserved it for a panel of more than 1,000 partner companies, who have tested it for a year and a half. The competing platform of Slack aims to provide organizations with an effective means of communication and collaborative work, very close to the Facebook that employees are used to in their daily lives, but in an environment reserved for the company and to its partners.

With a price that varies between 1 and 3 dollars per month and per active user depending on the size of the structure, Facebook At Work thus offers different collaboration tools put at the service of the company: creation of groups for teams or projects, Live videos, video conferences, publications and reactions, automated translation of messages (useful for multinationals or companies that welcome expatriates), audio discussions, search filters,…

src: https://www.numerama.com/business/200660-avec-workplace-facebook-pourrait-devenir-obligatoire-dans-votre-entreprise.html

![Launch%20of%20Workplace%20which%20follows%20Facebook%20at%20work/Untitled.png](Launch%20of%20Workplace%20which%20follows%20Facebook%20at%20work/Untitled.png)