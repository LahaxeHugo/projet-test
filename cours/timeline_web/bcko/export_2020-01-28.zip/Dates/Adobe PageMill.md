# Adobe PageMill

Année: 1995
Catégorie: Launch 🚀
Credits: https://thehistoryoftheweb.com/timeline/?date_from=1994&date_to=1996
Mois - Jour: 28 December
État: Complet ✅

Adobe launched PageMill, is a visual tool for creating websites, also called as a  WYSIWYG (What You See Is What You Get) software that allows content to be edited in a form that resembles its appearance when printed or displayed as a finished product (such as a printed document, web page, or slide presentation).
Originally, PageMill offered basic layout and content editing, but starting in version 2.0, grows to include a robust table and frames editor and a host of advanced visual features.

![Adobe%20PageMill/Untitled.png](Adobe%20PageMill/Untitled.png)

![Adobe%20PageMill/Untitled%201.png](Adobe%20PageMill/Untitled%201.png)