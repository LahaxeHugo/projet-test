# Lauch of Favicon

Année: 1999
Catégorie: Launch 🚀
Credits: https://sitechecker.pro/fr/what-is-favicon/
Credits: https://thehistoryoftheweb.com/timeline/?date_from=all
Mois - Jour: 1 Février
État: Complet ✅

Favicons are first introduced in Internet Explorer 5 so websites can display small icons next to their URL in a user’s favorite list. Browsers would eventually use favicon’s in a variety of places, though they would not become an official part of HTML standards until HTML5.

![Lauch%20of%20Favicon/Untitled.png](Lauch%20of%20Favicon/Untitled.png)