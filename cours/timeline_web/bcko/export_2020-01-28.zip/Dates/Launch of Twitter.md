# Launch of Twitter

Année: 2006
Catégorie: Launch 🚀
Credits: https://www.blogdumoderateur.com/twitter-nouveau-design-juillet-2019/
Credits: https://fr.wikipedia.org/wiki/Twitter
Mois - Jour: 21 Mars
État: Complet ✅

Twitter is a microblogging social network managed by Twitter Inc. It allows a user to send free short messages, called tweets, over the internet, instant messaging or SMS. These messages are limited to 280 characters (140 characters until November 2017).
Twitter was created on March 21, 2006 by Jack Dorsey, Evan Williams, Stone Biz and Noah Glass. The online service has quickly become popular. On March 5, 2017, it has 313 million active users per month, 500 million tweets sent per day and is available in more than forty languages. In 2018, Twitter announced for the first time to have made a profit, especially as a result of budget restrictions. The headquarters of Twitter Inc. are located in San Francisco, USA.

![Launch%20of%20Twitter/Untitled.png](Launch%20of%20Twitter/Untitled.png)

[]()