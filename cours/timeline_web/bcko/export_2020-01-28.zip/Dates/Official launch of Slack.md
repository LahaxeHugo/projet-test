# Official launch of Slack

Année: 2014
Catégorie: Launch 🚀
Mois - Jour: Février
État: Complet ✅

With Slack, teamwork makes sense and distance is no longer a barrier to collaboration.
From this platform, you can organize meetings, discuss the budget or set up a project and follow its progress from beginning to end.
You will be closer to your team and each member will be able to easily access the updates made as part of your projects.
Collaboration takes on a more professional dimension, because no matter where each member of your team is, you will be able to gather them quickly without having to move, moreover, the meeting will be interactive and everyone can intervene as in the case of a round table.
To better enjoy, performance Slack offers an application on different devices, you then have the choice between the application for the web, for Android and for iOS depending on the terminal you use.

src: [https://junto.fr/blog/slack/](https://junto.fr/blog/slack/)

![Official%20launch%20of%20Slack/Untitled.png](Official%20launch%20of%20Slack/Untitled.png)