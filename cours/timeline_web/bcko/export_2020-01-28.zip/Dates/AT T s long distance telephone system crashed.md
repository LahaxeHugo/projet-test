# AT&T's long-distance telephone system crashed.

Année: 1990
Catégorie: Crash
Credits: http://www.mit.edu/hacker/part1.html
Mois - Jour: 15 Janvier
État: Complet ✅

60 000 people lost their telephone service completely.

For nine hours, over 75 million long-distance calls went awry due to an error in a single line of code in a software patch made weeks earlier to AT&T's computer-operated electronic switches (4ESS).

The crash created a large dark cloud of suspicion that would color certain people's assumptions and actions for months. 

The Crash of January 15 gave the Hacker Crackdown its sense of edge and its sweaty urgency. It made people, powerful people in positions of public authority, willing to believe the worst. And, most fatally, it helped to give investigators a willingness to take extreme measures and the determination to preserve almost total secrecy.