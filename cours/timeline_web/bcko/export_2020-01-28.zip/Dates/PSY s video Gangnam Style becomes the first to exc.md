# PSY's video "Gangnam Style" becomes the first to exceed the symbolic figure of one billion views on the Youtube

Année: 2012
Catégorie: Step
Mois - Jour: 21 Décembre
État: Complet ✅

It is a worldwide success, particularly through its broadcast on video sharing sites, the official music video of the song becoming the most watched in history YouTube, then the first video having exceeded one billion views December 21, 2012, then the 2 billion on May 31, 2014.
Gangnam Style was dethroned in the number of views on July 11, 2017 by the clip See you again by Wiz Khalifa and Charlie Puth after five years at its head.

src : [https://fr.wikipedia.org/wiki/Gangnam_Style](https://fr.wikipedia.org/wiki/Gangnam_Style)

![PSY%20s%20video%20Gangnam%20Style%20becomes%20the%20first%20to%20exc/Untitled.png](PSY%20s%20video%20Gangnam%20Style%20becomes%20the%20first%20to%20exc/Untitled.png)