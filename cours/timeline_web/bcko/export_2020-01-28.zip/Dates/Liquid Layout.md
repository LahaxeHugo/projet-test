# Liquid Layout

Année: 1995
Catégorie: Innovation 🎢
Credits: https://thehistoryoftheweb.com/timeline/?date_from=all
Mois - Jour: 1er Décembre
État: Complet ✅

A new approach to laying out designs on the web, Liquid Layout advocates for the use of percentage width tables over the predominantly fixed-width designs of the ’90’s. When set in percentages, websites are able to expand or narrow based on the resolution it is being rendered in.