# Birth of the National Commission for Informatics and Liberties in France (CNIL)

Année: 1978
Catégorie: Commitment 📝
Mois - Jour: 6 Janvier
État: Complet ✅

The end of the decade saw the first concerns about the impact of the digitization of administrative files on freedoms. In 1978, the CNIL was created in France to ensure that information technology remains at the service of citizens and that it does not affect human identity, human rights or privacy.

src : [https://fr.m.wikipedia.org/wiki/Révolution_numérique](https://fr.m.wikipedia.org/wiki/R%C3%A9volution_num%C3%A9rique)

![Birth%20of%20the%20National%20Commission%20for%20Informatics%20a/Untitled.png](Birth%20of%20the%20National%20Commission%20for%20Informatics%20a/Untitled.png)