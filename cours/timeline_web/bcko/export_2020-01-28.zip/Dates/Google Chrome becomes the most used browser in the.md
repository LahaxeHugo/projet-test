# Google Chrome becomes the most used browser in the world

Année: 2012
Catégorie: Step
Mois - Jour: Juin
État: Complet ✅

Chrome has outperformed Internet Explorer on desktops. Google's browser climbs slowly but surely, with an acceleration phase. At the same time, the opposite is true for Internet Explorer. To the point that in May the two curves meet. In the end, Chrome is slightly ahead.

src: [https://gs.statcounter.com/](https://gs.statcounter.com/)

![Google%20Chrome%20becomes%20the%20most%20used%20browser%20in%20the/Untitled.png](Google%20Chrome%20becomes%20the%20most%20used%20browser%20in%20the/Untitled.png)