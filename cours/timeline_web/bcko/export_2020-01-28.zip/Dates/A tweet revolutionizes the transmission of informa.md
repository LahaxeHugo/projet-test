# A tweet revolutionizes the transmission of information

Année: 2009
Catégorie: Innovation 🎢
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html
Mois - Jour: 15 Janvier
État: Complet ✅

"There is a plane in the Hudson". 

On January 15, 2009, a plane landed on the Manhattan River. On one of the ferries around, Janis Krums takes a photo with his iPhone, which he publishes on Twitter - a gesture still relatively rare at the time. The image will spread around the world which revolutionizes the transmission of the information and reconsiders what a media truly is.

![A%20tweet%20revolutionizes%20the%20transmission%20of%20informa/Untitled.png](A%20tweet%20revolutionizes%20the%20transmission%20of%20informa/Untitled.png)

Parallèle - Favellas à Rio