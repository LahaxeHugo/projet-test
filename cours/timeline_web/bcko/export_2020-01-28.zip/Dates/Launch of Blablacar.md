# Launch of Blablacar

Année: 2006
Catégorie: Launch 🚀
Credits: https://blog.blablacar.fr/blablalife/nouveautes/nouveautes-blablacar/du-nouveau-sur-blablacar
Credits: https://fr.wikipedia.org/wiki/BlaBlaCar
Mois - Jour: 16 Septembre
État: Complet ✅

Created in 2004 under the name of [covoiturage.fr](http://covoiturage.fr/), it is a carpooling platform to connect drivers and passengers wishing to share a car trip and the associated costs. Drivers publish their available seats and passengers buy them online, on journeys whose average distance is 330 kilometers. With 70 million users in 2019, BlaBlaCar is the world leader in carpooling.

![Launch%20of%20Blablacar/Untitled.png](Launch%20of%20Blablacar/Untitled.png)