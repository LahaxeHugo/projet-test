# Pizza Hut Website launched

Année: 1994
Catégorie: Innovation 🎢
Credits: https://thehistoryofweb.design
État: Complet ✅

Locals from Santa Cruz, California could order food online for the first time, which changed the way that people have access to food and stuff in general. They could literally sit down at a computer, open up their favorite browser, and order a pizza online.

At the beginning, Pizza Hut wanted to experience something else, and verify if the World Wide Web had a real shot at a future. This experiment was proposed by an ambitious Pizza Hut owner in California and developed by several people at a development shop known as Santa Cruz Operation (SCO).

![Pizza%20Hut%20Website%20launched/Untitled.png](Pizza%20Hut%20Website%20launched/Untitled.png)