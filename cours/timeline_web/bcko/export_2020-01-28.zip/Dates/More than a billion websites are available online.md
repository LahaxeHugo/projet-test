# More than a billion websites are available online

Année: 2014
Catégorie: Step
État: Complet ✅

By "web sites", it is of course understood a unique host name, ie a name that can be resolved by using a server name in an IP address.
It should be noted that about 75% of these sites are not active, but are parked domain names that sometimes redirect users to another site.

src: [https://www.arobasenet.com/2014/09/1-milliard-sites-web-dans-le-monde-1200.html](https://www.arobasenet.com/2014/09/1-milliard-sites-web-dans-le-monde-1200.html)

![More%20than%20a%20billion%20websites%20are%20available%20online/Untitled.png](More%20than%20a%20billion%20websites%20are%20available%20online/Untitled.png)