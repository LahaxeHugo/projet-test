# Wikipedia launches

Année: 2001
Catégorie: Launch 🚀
Credits: https://en.wikipedia.org/wiki/History_of_Wikipedia
Mois - Jour: 15 Janvier
État: Complet ✅

Wikipedia is a multilingual online encyclopedia created and maintained as an open collaboration project using a wiki-based editing system. It is the largest and most popular general reference work on the World Wide Web.  
Wikipedia features exclusively free content and no commercial ads, and changed forever the way that people have access to information.

![Wikipedia%20launches/Untitled.png](Wikipedia%20launches/Untitled.png)