# Norway became the first country to start switching off FM Radio and switching to DAB, a digital broadcasting technology.

Année: 2017
Catégorie: Commitment 📝
Mois - Jour: 11 Janvier
État: Complet ✅

The switchover was completed when many of Norway’s most remote regions had their digital signals switched on, allowing the government to order that the traditional signal must be switched off.

But many cars are not equiped with devices allowing them to use those new radio signal.

src: [https://www.independent.co.uk/life-style/gadgets-and-tech/news/norway-fm-radio-dab-switchover-switch-off-signal-svalbard-britain-switzerland-roberts-a8108456.html](https://www.independent.co.uk/life-style/gadgets-and-tech/news/norway-fm-radio-dab-switchover-switch-off-signal-svalbard-britain-switzerland-roberts-a8108456.html)

![Norway%20became%20the%20first%20country%20to%20start%20switching/Untitled.png](Norway%20became%20the%20first%20country%20to%20start%20switching/Untitled.png)