# Pets.com annoucnes that it is closing. It went from an IPO on a major stock exchange (the Nasdaq) to liquidation in 268 days. US$300 million of investment capital vanished with the company's failure.

Année: 2000
Catégorie: Announcement
Mois - Jour: 6 Novembre