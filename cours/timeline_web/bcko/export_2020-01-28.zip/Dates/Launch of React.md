# Launch of React

Année: 2013
Catégorie: Launch 🚀
Mois - Jour: 1er Mars
État: Complet ✅

Developers at Facebook release React, a framework for building user interfaces on the web. Originally inspired by the PHP framework XHP, React embraces the idea of components, and allows users to create individual components which respond and automatically update based on data and content changes.

src: [https://thehistoryoftheweb.com/comparing-the-why-of-single-page-app-frameworks/](https://thehistoryoftheweb.com/comparing-the-why-of-single-page-app-frameworks/)

![Launch%20of%20React/Untitled.png](Launch%20of%20React/Untitled.png)