# Operation Sundevil

Année: 1990
Catégorie: Hackers 👾
Credits: http://www.mit.edu/hacker/part3.html
Mois - Jour: 1er Janvier
État: Complet ✅

Operation Sundevil was a 1990 nationwide United States Secret Service crackdown on "illegal computer hacking activities." It involved raids in approximately fifteen different cities and resulted in three arrests and the confiscation of computers, the contents of electronic bulletin board systems (BBSes), and floppy disks.

The several arrests and trials conducted to the creation of the Electronic Frontier Foundation : 

[Creation of the Electronic Frontier Foundation (EFF)](Creation%20of%20the%20Electronic%20Frontier%20Foundation%20EFF.md)

Operation Sundevil is also considered as one of the preliminary attacks against "Legion of Doom" and inspired Bruce Sterling for the release of "The Hacker Crackdown".

![Operation%20Sundevil/Untitled.png](Operation%20Sundevil/Untitled.png)