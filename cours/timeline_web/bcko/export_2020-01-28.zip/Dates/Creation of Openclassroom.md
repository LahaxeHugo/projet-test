# Creation of Openclassroom

Année: 1999
Catégorie: Launch 🚀
Credits: https://lareclame.fr/dragonrouge/realisations/corporate-branding-openclassrooms
Credits: https://fr.wikipedia.org/wiki/OpenClassrooms
Mois - Jour: 10 Novembre
État: Complet ✅

OpenClassrooms is an online school created by Mathieu Nebra and Pierre Dubuc who offers its members certification courses and courses leading to a profession of the future, carried out internally, by schools, universities, or by partner companies as Microsoft or IBM. Until 2018, any member of the site could be author, via a tool called "Course Lab". Many courses are from the community, but are no longer put forward. Initially oriented around computer programming, the platform covers since 2013 broader themes such as marketing, entrepreneurship and science.
Created in 1999 under the name of Site du Zero, it is formed mainly on the basis of volunteer contributions offering tutorials popularized with a light tone on various computer topics. Following the success and the end of the studies of the managers, the company Simple IT, renamed then OpenClassrooms, is founded in order to perpetuate the site. It bases its economic model on the issue of paid certifications and offers a subscription to be followed by a mentor.

![Creation%20of%20Openclassroom/Untitled.png](Creation%20of%20Openclassroom/Untitled.png)