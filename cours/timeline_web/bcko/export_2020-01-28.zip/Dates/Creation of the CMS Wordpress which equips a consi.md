# Creation of the CMS Wordpress, which equips a considerable number of sites

Année: 2003
Catégorie: Launch 🚀
Credits: https://fr.wordpress.org/
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html
Mois - Jour: 27 Mai
État: Complet ✅

This open source software has quickly become the most popular CMS (content management system), these tools to create and manage sites online. Customizable ad infinitum, it was particularly popular with bloggers who felt cramped in blog platforms too uniform.

![Creation%20of%20the%20CMS%20Wordpress%20which%20equips%20a%20consi/Untitled.png](Creation%20of%20the%20CMS%20Wordpress%20which%20equips%20a%20consi/Untitled.png)