# Lauch of WhatsApp

Année: 2009
Catégorie: Launch 🚀
Credits: https://www.whatsapp.com/?lang=fr
Credits: https://fr.wikipedia.org/wiki/WhatsApp
Mois - Jour: 3 Mai
État: Complet ✅

WhatsApp (or WhatsApp Messenger) is a cross-platform mobile application that provides an end-to-end encrypted instant messaging system via both the Internet and mobile networks.

WhatsApp was a great success at the turn of the year 2010. The app, created in 2009 by Jan Koum and Brian Acton, two former Yahoo! with the goal of replacing SMS, was used daily by more than a billion people in 2017.

Indeed, like its instant messenger ancestors, ICQ (1998), MSN Messenger (1999, integrated with Skype), or Facebook Messenger (or "instant chat" module of the website, 2011); Like its competitor Google Hangouts (2013), WhatsApp can send a message (text message or voice mail) to one or more contacts via the Internet for free. This requires that not only the sender of the message, but also all recipients of the message are users of the application.

The main use of WhatsApp is the free sending of messages from abroad or using the 4G subscription of the phone or a Wi-Fi connection. The sending is equivalent to the sending of an SMS provided that the correspondent installed the application on his equipment.

Since 2017, Whatsapp allows the "removal for everyone" of images or videos posted by mistake. The security consultant Shitesh Sachan discovers in 2019 that the removal is random on iOS without this discovery emigration messaging developers.

![Lauch%20of%20WhatsApp/Untitled.png](Lauch%20of%20WhatsApp/Untitled.png)