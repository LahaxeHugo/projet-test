# First Android phone

Année: 2008
Catégorie: Innovation 🎢
Credits: https://www.phonandroid.com/utiliser-android-google.html
Credits: https://fr.wikipedia.org/wiki/Android#targetText=Le%20premier%20mobile%20commercialis%C3%A9%20sous,depuis%20le%2012%20mars%202009%20.
Mois - Jour: 22 Octobre
État: Complet ✅

The first Android-powered mobile was the HTC G1 / Dream produced by the Taiwan-based company HTC, launched in the US on the T-Mobile network on October 22, 2008. As a reminder, Android is a mobile operating system based on the kernel Linux and currently developed by Google.

![First%20Android%20phone/Untitled.png](First%20Android%20phone/Untitled.png)