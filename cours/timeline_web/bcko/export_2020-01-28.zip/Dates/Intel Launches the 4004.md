# Intel Launches the 4004

Année: 1971
Catégorie: Launch 🚀
Mois - Jour: 1er Mars
État: Complet ✅

The Intel 4004 is the first commercially available microprocessor and the first in a long line of Intel CPU's. It was first produced exclusively for the industrialist who sponsored its development, Busicom, in March 1971. After lifting the exclusivity clause, Intel announced its commercialization on November 15, 1971.

Despite this innovation, the 4004 remains less powerful than the minicomputer processors of the same era. On the other hand, it makes it possible to imagine building computers much cheaper and smaller than these: microcomputers.

![Intel%20Launches%20the%204004/Intel_C4004_b.jpg](Intel%20Launches%20the%204004/Intel_C4004_b.jpg)