# Closure of Google Wave

Année: 2012
Catégorie: Announcement
Mois - Jour: 30 avril
État: Complet ✅

-A product not finished
If you take a closer look, you'll notice that Google Wave has never been out of beta. Google tends to post a little too long its mention "Labs". Certainly, for some services it worked but not for the wave!

-A deplorable invitation system
Announced since May 2009 as an innovative service, it was not until September 2009 to finally see land invitations. And again, 100,000 is not enough! The main interest of a service like Google Wave is to interact with the world (like Twitter and Facebook).

-The absence of evolution
Although the Google Wave APIs were made available to everyone, no tools or applications really came into existence. Maybe with a few extra options, the wave would have been a wonderful toy!

-Facebook and Twitter have already done it!
The main failure is certainly due to the two biggest social networks of the moment: Facebook and Twitter. Google Wave is nothing more than a mix of these two! Recreating something that already exists does not serve much purpose.

src: [http://www.autourduweb.fr/5-raisons-contribue-mort-google-wave/](http://www.autourduweb.fr/5-raisons-contribue-mort-google-wave/)

![Closure%20of%20Google%20Wave/Untitled.png](Closure%20of%20Google%20Wave/Untitled.png)