# French host OVH raises 250 million euros and crosses the billion euro valuation bar

Année: 2016
Catégorie: Step
Mois - Jour: 13 août
État: Complet ✅

OVHcloud, formerly OVH, is a French company specializing in cloud computing services. Founded in 1999 by Octave Klaba, the group offers public and private cloud solutions, dedicated servers, shared hosting, housing (or colocation), registration of domain names, access provision Internet via ADSL, VDSL, SDSL and fiber lines, as well as IP telephony.

The company claims to serve more than one million customers worldwide, supported by a network of 28 data centers across Europe, North America and Asia-Pacific.

The company has deployed its own fiber optic network around the world and claims a total capacity of 10 Tbit / s and more than 260,000 hosted physical servers, which is one of the world's largest servers.

OVHcloud is present in 19 countries around the world and in October 2017 had a workforce of more than 2,000 employees.

On October 8, 2019, OVH announced that it would change its name to OVHcloud.

src: https://fr.wikipedia.org/wiki/OVHcloud

![French%20host%20OVH%20raises%20250%20million%20euros%20and%20cross/Untitled.png](French%20host%20OVH%20raises%20250%20million%20euros%20and%20cross/Untitled.png)