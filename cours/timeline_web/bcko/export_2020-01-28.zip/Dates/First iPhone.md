# First iPhone

Année: 2007
Catégorie: Innovation 🎢
Credits: https://www.marketwatch.com/story/breaking-down-walls-of-phones-web-gardens
État: Complet ✅

Apple releases the iPhone in 2007, equipped with a mobile version of Safari. The iPhone was the first smartphone to display the web almost as it appeared on the desktop with a zoom-in, zoom-out feature that allows users to read text and enlarge photos.

As they famously said in an iPhone ad, "This is not a watered-down version of the Internet... It's just the Internet, on your phone."