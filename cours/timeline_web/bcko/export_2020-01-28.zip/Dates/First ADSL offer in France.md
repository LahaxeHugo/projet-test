# First ADSL offer in France

Année: 1999
Catégorie: Launch 🚀
Credits: https://www.zdnet.fr/actualites/il-y-a-20-ans-l-adsl-fait-entrer-la-france-dans-le-haut-debit-39887067.htm
Mois - Jour: 1 December
État: Complet ✅

![First%20ADSL%20offer%20in%20France/netissimo.gif](First%20ADSL%20offer%20in%20France/netissimo.gif)

ADSL, which has been in the experimental phase since 1994 in France Télécom's research laboratories, is launched commercially in France at the initiative of the incumbent operator. The service provider Wanadoo, still a subsidiary of the operator France Telecom, is the first to put on the market an ADSL broadband access pack, the famous Netissimo, available from January 12.

ADSL technology then makes it possible to use copper cable telephone links to transmit high-speed digital data in asymmetric connection. The service experienced by France Telecom offers a bandwidth of 512 kbps in reception and 128 kbps in transmission. What to forget the low rates then available to French Internet users.

The conditions of adhesion to this new offer are however drastic: who wants to take advantage of this new technology must imperatively reside in Paris and subscribe ahead of 12 months and above all have to pay 265 francs per months.