# Justin Hall : pioneer blogger

Année: 1994
Catégorie: Innovation 🎢
Credits: http://links.net/
Credits: https://www.buzzly.fr/le-web-a-25-ans-decouvrez-les-dates-qui-ont-marque-son-histoire.html
État: Complet ✅

As a student, Justin decide to start a personal diary on the web called "Justin's Links from the Underground" which offered one of the earliest guided tours of the web. The site came to focus on Hall's life in intimate detail. 

In December, 2004, New York Times Magazine referred to him as "the founding father of personal blogging."

The site still exists, is still active, and the design has not changed much! [Www.links.net](http://www.links.net/)

![Justin%20Hall%20pioneer%20blogger/Untitled.png](Justin%20Hall%20pioneer%20blogger/Untitled.png)

Justin Hall in 2008