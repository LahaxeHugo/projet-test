# Windows 10 release

Année: 2015
Catégorie: Launch 🚀
Mois - Jour: 29 juillet
État: Complet ✅

Among the novelties of Windows 10, we find:
• The Edge browser, formerly called "Project Spartan", which aims to replace Internet Explorer
• the voice assistant for the user Cortana which is Microsoft's answer to Apple's Siri
• the return of the Start menu, which had disappeared under Windows 8, and which is a merger of the old Start menu and the Metro interface of Windows 8. It seems effective in terms of the interface and features.
• highlighting the Store in the Start menu.

src: [https://www2.stardust-testing.com/blog-fr/ce_que_pense_stardust/quels-changements-engendre-windows-10-pour-les-testeurs](https://www2.stardust-testing.com/blog-fr/ce_que_pense_stardust/quels-changements-engendre-windows-10-pour-les-testeurs)

![Windows%2010%20release/Untitled.png](Windows%2010%20release/Untitled.png)