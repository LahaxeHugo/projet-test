# Release of Windows Vista

Année: 2007
Catégorie: Launch 🚀
Mois - Jour: 30 janvier
État: Complet ✅

Memory management has grown to 4GB on 32-bit editing and up to 128GB on Vista's 64-bit version.

Vista is not far from 20,000 drivers, while Windows XP included only half! No more floppies for additional drivers by pressing F6 at the beginning of the installation. If a specific driver is needed, just click Load Driver and choose storage media. And finally the USB keys are allowed to load drivers!

Native Bluetooth: Vista compatible with some USB Bluetooth adapters at installation, Input device support (keyboard / mouse) before actual system boot.

During Vista installation, no need to enter the product key and you can choose which edition to install. You will have 30 days to test and then enter your corresponding key otherwise the system will restrict the features!

Vista is installed with DirectX 10, which is not intended for Windows XP.

src: [http://www.topvista.fr/nouveautes-vista.html](http://www.topvista.fr/nouveautes-vista.html)

![Release%20of%20Windows%20Vista/Untitled.png](Release%20of%20Windows%20Vista/Untitled.png)