# Children’s Online Privacy Protection Act (COPPA)

Année: 1998
Catégorie: Law 👨‍⚖️
Credits: https://thehistoryoftheweb.com/timeline/?date_from=1997&date_to=2001
Mois - Jour: October 21
État: Complet ✅

The Children's Online Privacy Protection Act (COPPA) is a law created in the United States in 1998 to protect children's private life on Internet.

This law concerns the collect of informations on less than 13 years minors. It established the elements that a website has to put in its charter of protection of the private life, as well as requiring parental (or a legal gardian) consent before any data can be collected, and restrictions regarding online commerces.

Over the years, it has come under fire for sidestepping some of the more complex issues facing children online.

It has nothing to do with the COPA, a law that protects children against violent content.