# Tim Cook announces that a billion iPhones have been sold since its creation

Année: 2016
Catégorie: Step
Mois - Jour: juillet
État: Complet ✅

It will have taken 27 years to sell 1 billion PCs, 49 years to pass the milestone of one billion visitors to Disney Parks, 58 years to manufacture 1 billion gallons (4.5 billion liters) of Coca-Cola, or 60 years at Warren Buffet to become a billionaire. However, it only took Apple 9 years to sell 1 billion iPhones worldwide.

It was during an internet meeting in Cupertino (California) that Tim Cook, the boss of Apple, announced the good news: "The iPhone is one of the most important products in history having transformed the world. It has become more than a companion. The iPhone is truly an essential part of our daily lives and takes care of much of what we do during the day, "he said.

src: https://www.purebreak.com/news/apple-deja-un-milliard-d-iphone-vendus/106491

![Tim%20Cook%20announces%20that%20a%20billion%20iPhones%20have%20bee/Untitled.png](Tim%20Cook%20announces%20that%20a%20billion%20iPhones%20have%20bee/Untitled.png)