# Tim Berners Lee proposal : Information management a proposal

Année: 1989
Catégorie: Publishing 📚
Mois - Jour: 15 Mars
État: Complet ✅

Berners-Lee had submitted his idea in a paper titled “Information Management: A Proposal,” in which he argued for the creation of an information management system he described as “a large hypertext database with typed links.” The idea was to offer universal access to use the then-nascent internet, not just to communicate, but to store and access vast troves of online documents and data.

src: [https://www.cnbc.com/2019/03/12/feedback-world-wide-web-inventor-berners-lee-got-from-boss-on-the-idea.html](https://www.cnbc.com/2019/03/12/feedback-world-wide-web-inventor-berners-lee-got-from-boss-on-the-idea.html)

![Tim%20Berners%20Lee%20proposal%20Information%20management%20a%20/Untitled.png](Tim%20Berners%20Lee%20proposal%20Information%20management%20a%20/Untitled.png)