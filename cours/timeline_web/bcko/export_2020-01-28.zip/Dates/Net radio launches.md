# Net radio launches

Année: 1995
Catégorie: Launch 🚀
Mois - Jour: Février
État: Complet ✅

Radio HK, founded by Norman Hajjar, was the first full-time, Internet-only radio station that began by broadcasting music from unsigned and independent bands. It's estimated the station reached 100,000 people in 46 countries and held a trial license from ASCAP, making it a pioneer for instigating the legitimate broadcasting of Internet music.

src: https://www.cnet.com/news/the-50-most-significant-moments-of-internet-history/

![Net%20radio%20launches/Untitled.png](Net%20radio%20launches/Untitled.png)