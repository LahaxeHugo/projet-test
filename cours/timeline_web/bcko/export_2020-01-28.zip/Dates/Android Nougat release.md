# Android Nougat release

Année: 2016
Catégorie: Launch 🚀
Mois - Jour: 22 août
État: Complet ✅

Android Nougat offers a striking novelty: multi-window mode. A feature that allows you to see two apps side by side, and that we already find at Apple or Microsoft ... but also on Android devices from Samsung. Drag and drop can also be performed between two apps thus opened in "split screen".

With Android Nougat, double-clicking the "back" button (the one on the right) will switch to previous open apps - taking advantage of the multi-window mode.

src: https://www.journaldunet.com/solutions/dsi/1174773-android-nougat-ou-android-7-0-les-nouveautes/

![Android%20Nougat%20release/Untitled.png](Android%20Nougat%20release/Untitled.png)