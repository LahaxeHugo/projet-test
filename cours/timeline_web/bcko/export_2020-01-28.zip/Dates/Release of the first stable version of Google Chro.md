# Release of the first stable version of Google Chrome

Année: 2008
Catégorie: Launch 🚀
Mois - Jour: 11 Décembre