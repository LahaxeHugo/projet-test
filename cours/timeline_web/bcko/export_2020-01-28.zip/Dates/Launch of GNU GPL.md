# Launch of GNU GPL

Année: 1989
Catégorie: Launch 🚀
Credits: https://en.wikipedia.org/wiki/GNU_General_Public_License
Mois - Jour: 25 Février
État: Complet ✅

![Launch%20of%20GNU%20GPL/tlchargement_(1).png](Launch%20of%20GNU%20GPL/tlchargement_(1).png)

The GNU General Public License (GNU GPL) is a widely-used free software license, which guarantees end users the freedom to run, study, share and modify the software.

The license was originally written by Richard Stallman of the Free Software Foundation (FSF) for the GNU Project, and grants the recipients of a computer program the rights of the Free Software Definition. 

GPL was the first copyleft license for general use, which means that derivative work must be open-source and distributed under the same license terms.