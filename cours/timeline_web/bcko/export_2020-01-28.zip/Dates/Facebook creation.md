# Facebook creation

Année: 2004
Catégorie: Launch 🚀

![Facebook%20creation/Untitled.png](Facebook%20creation/Untitled.png)

[https://www.monacomatin.mc/technologie/mark-zuckerberg-veut-changer-la-strategie-de-facebook-et-promet-de-mieux-respecter-la-vie-privee-mais-ce-nest-pas-gagne-304082](https://www.monacomatin.mc/technologie/mark-zuckerberg-veut-changer-la-strategie-de-facebook-et-promet-de-mieux-respecter-la-vie-privee-mais-ce-nest-pas-gagne-304082)