# Microsoft launches Windows 95

Année: 1995
Catégorie: Launch 🚀
Mois - Jour: 24 août
État: Complet ✅

With Windows 95, Microsoft messes with everything including a graphical environment completely redesigned with the appearance of a button "Start", a taskbar and buttons "reduce", "enlarge" and "close" on each window. The connection of the peripherals is simplified thanks to the "plug-and-play" system. Note that this is also the first time that the Internet Explorer browser is integrated with Windows.

src: https://geeko.lesoir.be/2015/11/18/levolution-de-windows-depuis-la-premiere-version-en-images/

![Microsoft%20launches%20Windows%2095/Untitled.png](Microsoft%20launches%20Windows%2095/Untitled.png)