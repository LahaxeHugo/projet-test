# Zombie computing

Année: 2007
Catégorie: Hackers 👾
Credits: img: http://blog.economie-numerique.net/2016/12/22/whats-a-zombie-computer-and-how-does-it-work/
Credits: https://www.lemondeinformatique.fr/actualites/lire-un-quart-des-pc-en-ligne-seraient-des-zombies-42915.html
Mois - Jour: Février
État: Complet ✅

![Zombie%20computing/zombie-computer-4a.jpg](Zombie%20computing/zombie-computer-4a.jpg)

In computing, a zombie is a computer connected to the Internet that has been compromised by a hacker, a computer virus, or a Trojan horse program and that can be used to perform malicious tasks of some kind or another. distance. 

Zombie computer botnets are often used to spread spam via email and launch denial of service attacks (DoS attacks). Most owners of "zombie" computers are unaware that their system is being used this way. Because the owner tends to ignore them, these computers are metaphorically compared to fictional zombies. A DDoS attack coordinated by multiple botnet machines also looks like a "horde of zombie attack", as the fictional zombie movies show.

According to Vinton Cerf,  great network specialist, president of ICANN, and co-inventor of the Internet TCP / IP communication protocol, nf the 600 million machines connected to the world, 100 to 150 million are infected by a Virus or a Trojan horse remotely controllable.