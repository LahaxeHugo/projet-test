# Why Software Is Eating The World,
Marc Andreessen in the Wall Street Journal

Année: 2011
Catégorie: Publishing 📚
Mois - Jour: 20 Septembre
État: Complet ✅

Marc Andreessen (born July 9, 1971) is a member of the student team at the University of Illinois who in 1993 developed Mosaic, the first full web browser available for Mac operating systems. OS, Windows and UNIX.

With the funds of James H. Clark, the founder of SGI (Silicon Graphics), he founded Netscape, the first company entirely oriented towards the Internet.

In 2009, he launched the design of a new browser called RockMelt.

In 2019, he announced that his company, Andreessen Horowitz, was about to register as a financial advisor.

src: [https://fr.wikipedia.org/wiki/Marc_Andreessen](https://fr.wikipedia.org/wiki/Marc_Andreessen)

src: [https://uptakedigital.zendesk.com/hc/en-us/articles/115001167933-Why-Software-Is-Eating-the-World](https://uptakedigital.zendesk.com/hc/en-us/articles/115001167933-Why-Software-Is-Eating-the-World)

![Why%20Software%20Is%20Eating%20The%20World%20Marc%20Andreessen%20i/Untitled.png](Why%20Software%20Is%20Eating%20The%20World%20Marc%20Andreessen%20i/Untitled.png)