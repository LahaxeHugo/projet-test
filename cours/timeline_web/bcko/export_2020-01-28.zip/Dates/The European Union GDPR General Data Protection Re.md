# The European Union GDPR (General Data Protection Regulation) law goes into effect on for companies who conduct business in the EU.

Année: 2018
Catégorie: Law 👨‍⚖️
Mois - Jour: 25 Mai
État: Complet ✅

The General Data Protection Regulation (GDPR) is the new European framework for the processing and circulation of personal data, elements on which companies rely to provide services and products. 

The aim is to be the new reference text in the European Union on personal data, replacing a directive dating from 1995.

src: [https://www.numerama.com/politique/329191-rgpd-tout-savoir-sur-le-reglement-sur-la-protection-des-donnees-si-vous-etes-un-internaute.html](https://www.numerama.com/politique/329191-rgpd-tout-savoir-sur-le-reglement-sur-la-protection-des-donnees-si-vous-etes-un-internaute.html)

![The%20European%20Union%20GDPR%20General%20Data%20Protection%20Re/Untitled.png](The%20European%20Union%20GDPR%20General%20Data%20Protection%20Re/Untitled.png)