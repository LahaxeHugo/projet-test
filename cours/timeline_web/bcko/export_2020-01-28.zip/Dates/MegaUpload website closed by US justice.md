# MegaUpload website closed by US justice

Année: 2012
Catégorie: Law 👨‍⚖️
Mois - Jour: 19 janvier
État: Complet ✅

The American courts reproach them for violating copyright by offering, on their site, movies, series and other pirated products. US authorities estimate the damage suffered by the cultural industry to $ 500 million. On the contrary, these activities would have allowed the network to pocket $ 175 million.
Megaupload allows you to share legal files but is in practice massively used to host pirated movies and albums. Megaupload Ltd, and another company related to the case, Vestor Ltd, have been indicted by a state of Virginia indictment chamber for copyright infringement and attempted racketeering and money laundering, offenses punishable by 20 years in prison.
The FBI and the US Department of Justice are suing seven people. They say they arrested in New Zealand the founder of Megaupload, the German Kim Dotcom also known as Kim Schmitz and Kim Tim Jim Vestor, apprehended along with two other people.

src: [https://www.lefigaro.fr/societes/2012/01/19/20005-20120119ARTFIG00753-la-justice-americaine-bloque-le-site-megaupload.php](https://www.lefigaro.fr/societes/2012/01/19/20005-20120119ARTFIG00753-la-justice-americaine-bloque-le-site-megaupload.php)

![MegaUpload%20website%20closed%20by%20US%20justice/Untitled.png](MegaUpload%20website%20closed%20by%20US%20justice/Untitled.png)