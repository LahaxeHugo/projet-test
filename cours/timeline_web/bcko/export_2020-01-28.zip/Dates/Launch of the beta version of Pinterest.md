# Launch of the beta version of Pinterest

Année: 2010
Catégorie: Launch 🚀
Mois - Jour: Mars
État: Complet ✅

Pinterest is an American website mixing the concepts of social networking and photo sharing, launched in 2010 by Paul Sciarra, Evan Sharp and Ben Silbermann. It allows its users to share their interests and pass through albums of photographs gleaned from the Internet. The name of the site is a portmanteau of the English words pin and interest.

src : [https://fr.wikipedia.org/wiki/Pinterest](https://fr.wikipedia.org/wiki/Pinterest)

![Launch%20of%20the%20beta%20version%20of%20Pinterest/Untitled.png](Launch%20of%20the%20beta%20version%20of%20Pinterest/Untitled.png)