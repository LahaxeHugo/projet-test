# Child Online Protection Act

Année: 1998
Catégorie: Law 👨‍⚖️
État: Complet ✅

The Child Online Protection Act (COPA) is an american law created to protect minors from porn content on internet. 

It follows the Supreme Court's invalidation of the Communications Decency Act, an older law that also targets Internet pornography. However, the Child Online Protection Act was in turn invalidated by federal courts, which found it to be an infringement on freedom of expression protected by the first amendment to the constitution.

It isn't the same as the Children’s Online Privacy Protection Act (COPPA)