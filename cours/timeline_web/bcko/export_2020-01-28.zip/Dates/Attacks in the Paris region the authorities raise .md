# Attacks in the Paris region, the authorities raise the tone in front of the platforms

Année: 2015
Catégorie: Announcement
Credits: https://fr.wikipedia.org/wiki/Attentats_du_13_novembre_2015_en_France
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html#date-2018
Mois - Jour: 13 Novembre
État: Complet ✅

The use by jihadists of large social networks like Facebook or Twitter to recruit and disseminate their propaganda concerns the governments of several Western countries, which threaten to legislate.

![Attacks%20in%20the%20Paris%20region%20the%20authorities%20raise%20/Untitled.png](Attacks%20in%20the%20Paris%20region%20the%20authorities%20raise%20/Untitled.png)