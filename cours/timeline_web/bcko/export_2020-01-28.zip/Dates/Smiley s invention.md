# Smiley's invention

Année: 1982
Catégorie: Publishing 📚
Credits: image: https://www.wired.com/2011/09/0919fahlman-proposes-emoticons/
Credits: https://www.buzzly.fr/le-web-a-25-ans-decouvrez-les-dates-qui-ont-marque-son-histoire.html
Mois - Jour: 19 Septembre
État: Complet ✅

![Smiley%20s%20invention/scott.jpg](Smiley%20s%20invention/scott.jpg)

The first message containing a smiley was sent by Scott Fahlman.

This event marks the first expression of feelings in a message.

The message is:

"19-Sep-82 11:44 Scott E Fahlman :-)
From: Scott E Fahlman

I propose that the following character sequence for joke markers: :-)

Read it sideways. Actually, it is probably more economical to mark
things that are NOT jokes, given current trends. For this, use : :-(