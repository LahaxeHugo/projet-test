# XML version 1.0

Année: 1998
Catégorie: Launch 🚀
Mois - Jour: 10 février
État: Complet ✅

The W3C publishes a specification for XML, a way to structure data readable by both machines and computers. XML is used heavily in web services, and allows for web servers and clients to relay information back and forth programatically.

src: [https://thehistoryoftheweb.com/soap-rest-odds/](https://thehistoryoftheweb.com/soap-rest-odds/)

![XML%20version%201%200/Untitled.png](XML%20version%201%200/Untitled.png)