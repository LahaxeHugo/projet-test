# Creation of the French site Leboncoin

Année: 2006
Catégorie: Launch 🚀
Credits: https://www.herault-tribune.com/articles/171556/economie-leboncoin-fait-sa-revolution-sur-le-net/
Credits: https://fr.wikipedia.org/wiki/Le_Bon_Coin#Fonctionnement
Mois - Jour: 28 Avril
État: Complet ✅

Leboncoin is a commercial advertising website, founded in France, during the year 2006, at the initiative of the Norwegian conglomerate Schibsted. Its business model is based on free service for individuals and linking local supply and demand. Users of the [leboncoin.fr](http://leboncoin.fr/) website may post classified ads presenting material goods (cars, furniture, clothing, real estate, etc.), services (eg vacation rentals) or job offers. Leboncoin is today the referent site of advertisements from private individuals to individuals and professionals in France.

![Creation%20of%20the%20French%20site%20Leboncoin/Untitled.png](Creation%20of%20the%20French%20site%20Leboncoin/Untitled.png)