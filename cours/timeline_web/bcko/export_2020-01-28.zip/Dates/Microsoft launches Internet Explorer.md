# Microsoft launches Internet Explorer

Année: 1995
Catégorie: Launch 🚀
Credits: https://fr.wikipedia.org/wiki/Internet_Explorer
Mois - Jour: 16 Août
État: Complet ✅

Internet Explorer, sometimes abbreviated IE, MIE or MSIE, is the web browser developed by the American company Microsoft and installed by default with Windows. Between the end of the 1990s, when it dethroned Netscape Navigator, until around 2012, it is the most used web browser in the world.

![Microsoft%20launches%20Internet%20Explorer/Untitled.png](Microsoft%20launches%20Internet%20Explorer/Untitled.png)