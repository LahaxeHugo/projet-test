# TOR (The Onion Reuter)

Année: 2002
Catégorie: Launch 🚀
Credits: https://www.complex.com/pop-culture/2013/12/evolution-of-tabs-web-browser-internet
Mois - Jour: September
État: Complet ✅

TOR (The Onion Reuter) is released in September 2002, with the goal of protecting the personal privacy of users by keeping data anonymous. It would later be used to host websites like Silk Road, which sold illegal goods, and NSA whistleblower Edward Snowden would use it to send secret documents to The Guardian.

This worldwide and decentralized network anonymizes the origin of each connection and the source of a session of Web browsing or instant messaging. However, this anonymization isn't sufficient because this application can submit annexes to identify people. In that case, TOR developped a web browser based on Firefox, the Tor Browser, and other modified applications to preserve the anonymity.