# Project Gutenberg

Année: 1971
Catégorie: Publishing 📚
Credits: image: http://librotheque.alwaysdata.net/2017/07/24/projet-gutenberg/
Credits: https://www.buzzly.fr/le-web-a-25-ans-decouvrez-les-dates-qui-ont-marque-son-histoire.html
Mois - Jour: 4 Juillet
État: Complet ✅

![Project%20Gutenberg/projet_gutenberg.jpg](Project%20Gutenberg/projet_gutenberg.jpg)

Project Gutenberg is a volunteer effort to digitize and archive cultural works, to "encourage the creation and distribution of eBooks". It was founded in 1971 by American writer Michael S. Hart and is the oldest digital library. Most of the items in its collection are the full texts of public domain books. The project tries to make these as free as possible, in long-lasting, open formats that can be used on almost any computer.

Michael Hart uses a computer from the Materials Research Lab to write the "Declaration of Independence of the United States" on ARPANET.
This 5 KB file was accessible to all users. This is the first "ebook" in history. Many volunteers joined him to write several other books such as "The Bible" or "Alice in Wonderland".