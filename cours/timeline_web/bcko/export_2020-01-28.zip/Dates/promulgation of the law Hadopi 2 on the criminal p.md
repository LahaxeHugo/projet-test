# promulgation of the law Hadopi 2, "on the criminal protection of literary and artistic property on the Internet"

Année: 2009
Catégorie: Law 👨‍⚖️
Mois - Jour: 31 Décembre
État: Complet ✅

The law n ° 2009-1311 relative to the penal protection of the literary and artistic property on Internet known as HADOPI 2 law, is a French law complementary to the law favoring the diffusion and the protection of the creation on Internet, known as HADOPI law. Its aim is to reintroduce the repressive aspect of the first law, which was declared partly unconstitutional by the Constitutional Council.

src: [https://fr.wikipedia.org/wiki/Loi_relative_à_la_protection_pénale_de_la_propriété_littéraire_et_artistique_sur_internet](https://fr.wikipedia.org/wiki/Loi_relative_%C3%A0_la_protection_p%C3%A9nale_de_la_propri%C3%A9t%C3%A9_litt%C3%A9raire_et_artistique_sur_internet)

![promulgation%20of%20the%20law%20Hadopi%202%20on%20the%20criminal%20p/Untitled.png](promulgation%20of%20the%20law%20Hadopi%202%20on%20the%20criminal%20p/Untitled.png)