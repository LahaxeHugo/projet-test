# Confinity merges with Xcom to become Paypal

Année: 1998
Catégorie: Launch 🚀
Credits: https://en.wikipedia.org/wiki/Confinity
Mois - Jour: 15 Mars
État: Complet ✅

![Confinity%20merges%20with%20Xcom%20to%20become%20Paypal/paypal.png](Confinity%20merges%20with%20Xcom%20to%20become%20Paypal/paypal.png)

Confinity Inc. was an American software company based in Silicon Valley, best known as the creator of PayPal. It was founded in December 1998 by Max Levchin, Peter Thiel, and Luke Nosek, initially as a Palm Pilot payments and cryptography company.

Confinity merged with [X](http://x.com/).com, founded by Elon Musk, in March 2000. The merged company became known as [X.](http://x.com/)com because this was thought to be a name with broader long-term potential than Confinity or PayPal. However, surveys showed that a majority of consumers considered the name [X.](http://x.com/)com vague and potentially pornographic and preferred that the company simply be called PayPal. After a corporate restructuring, the company adopted the name PayPal Inc.