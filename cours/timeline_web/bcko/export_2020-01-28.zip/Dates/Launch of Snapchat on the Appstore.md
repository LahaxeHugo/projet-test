# Launch of Snapchat on the Appstore

Année: 2011
Catégorie: Launch 🚀
Mois - Jour: Septembre
État: Complet ✅

Snapchat (or Snap in common parlance) is a free photo and video sharing application from Snap Inc., available on iOS and Android mobile platforms. It was designed and developed by students from Stanford University in California. The age required to download and use this application is set at 13.1,2.

Each photograph or video sent can only be viewed by its recipient for a period of one to ten seconds and recently, with no time limit. The company is estimated to be worth $ 24 billion in 20173. In 2016, the company changed its name to Snap Inc.4.

src: [https://fr.wikipedia.org/wiki/Snapchat](https://fr.wikipedia.org/wiki/Snapchat)

![Launch%20of%20Snapchat%20on%20the%20Appstore/Untitled.png](Launch%20of%20Snapchat%20on%20the%20Appstore/Untitled.png)