# The end of Hadopi is voted for 2022, in general indifference

Année: 2016
Catégorie: Law 👨‍⚖️
Mois - Jour: 28 avril
État: Complet ✅

The National Assembly adopted an ecologist amendment ending the controversial High Authority for the Dissemination of Works and Protection of Rights on the Internet (Hadopi) in 2022.

The executive failed to gather enough MPs to reject the amendment, which was adopted in an almost empty hemicyle - four votes in favor, three against.

src: [https://www.lemonde.fr/pixels/article/2016/04/29/les-deputes-votent-la-suppression-de-la-hadopi-pour-2022_4910946_4408996.html](https://www.lemonde.fr/pixels/article/2016/04/29/les-deputes-votent-la-suppression-de-la-hadopi-pour-2022_4910946_4408996.html)

![The%20end%20of%20Hadopi%20is%20voted%20for%202022%20in%20general%20ind/Untitled.png](The%20end%20of%20Hadopi%20is%20voted%20for%202022%20in%20general%20ind/Untitled.png)