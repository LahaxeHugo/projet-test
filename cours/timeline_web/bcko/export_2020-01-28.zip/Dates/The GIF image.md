# The GIF image

Année: 1987
Catégorie: Innovation 🎢
Mois - Jour: Juin
État: Complet ✅

CompuServe developers released the GIF image, not knowing the algorithm had a patent pending. The Graphics Interchange Format became insanely popular for its efficiency, and years later transformed the Web into full colour. In 1986, Unisys successfully patented the LZW algorithm, but did nothing to stop CompuServe. A few years later, the two companies banded together and decreed developers must pay to use the format. Unhappy developers revolted.

src: https://www.cnet.com/news/the-50-most-significant-moments-of-internet-history/

![The%20GIF%20image/Untitled.png](The%20GIF%20image/Untitled.png)