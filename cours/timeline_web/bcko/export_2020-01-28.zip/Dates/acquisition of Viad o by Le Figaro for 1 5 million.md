# acquisition of Viadéo by Le Figaro for 1.5 million euros

Année: 2016
Catégorie: Acquisition 💰
Mois - Jour: 23 décembre
État: Complet ✅

In bankruptcy since November Viadeo was officially taken over by Figaro Classifieds, the online classifieds subsidiary of the Figaro CCM Benchmark group, for 1.5 million euros, corresponding to around 15% of its market capitalization when the trading of the stock has been suspended (November 10). "The French courts on December 23 and the American courts on December 30 accepted the offer from Figaro Classifieds for the resumption of Viadeo activities," the group said in a statement. It thus wins over its competitors the Swedish Schibsted (which owns Leboncoin), Rivalis, SFAM Développement, Ethics Group and One More Company.

Of the 126 social network employees, 98 should be retained, including 20 interns and work-study students.

The operation will strengthen and "diversify the multi-brand strategy of Figaro Classifieds by integrating a professional social network into its existing" career "offer," the document added. The new owner will also refocus Viadeo on career management in France. "This year will be an opportunity for Viadeo to make a new start alongside Figaro Classifieds, the leader in employment and training on the Internet in France. This will give you even more career opportunities and visibility with 15,000 recruiters, "said the social network in a message to its members.

src: https://www.channelnews.fr/rachat-de-viadeo-figaro-classifieds-enterine-69060

![acquisition%20of%20Viad%20o%20by%20Le%20Figaro%20for%201%205%20million/Untitled.png](acquisition%20of%20Viad%20o%20by%20Le%20Figaro%20for%201%205%20million/Untitled.png)