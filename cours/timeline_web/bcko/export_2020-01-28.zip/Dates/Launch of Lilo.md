# Launch of Lilo

Année: 2015
Catégorie: Launch 🚀
Mois - Jour: Janvier
État: Complet ✅

Lilo is a French search looking to take on giants like Google and Yahoo – and it has grown to 700,000 users per month and a total number of searches of half a billion.

It invests 50% of its total revenue in social and environmental projects and has distributed €220,000 to 50 projects, including social enterprises, charitable organisations and co-ops.

Each time users search on Lilo they earn a symbolic drop of water, which represents the money gained from advertising linked to the web page. They are then asked to choose a project they want to support and the drop of water gets converted into money.

src: https://www.thenews.coop/116832/topic/french-ethical-search-engine-investing-profits-social-projects-co-ops/

![Launch%20of%20Lilo/Untitled.png](Launch%20of%20Lilo/Untitled.png)