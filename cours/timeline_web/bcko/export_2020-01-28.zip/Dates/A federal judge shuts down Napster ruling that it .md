# A federal judge shuts down Napster, ruling that it must find a way to stop users from sharing copyrighted material before it can go back online.

Année: 2001
Catégorie: Law 👨‍⚖️