# Adobe officially announce the end of Flash.

Année: 2015
Catégorie: Announcement
Credits: https://thehistoryofweb.design/2010
Mois - Jour: 30 Novembre
État: Complet ✅

Years ago, flash was used all over the web for making games or animation, because at that time there was no other easy way. But nowadays, it's outdated. 

Steve Job's open letter in April, "thoughts of flash" resulted in a huge aftershock. Almost overnight, Flash became a bad word and was widely shunned.

Google's "The wilderness Downtown" was the first website fully developed in HTML5 that really shook Flash, becoming the biggest game-changer in over a decade.

![Adobe%20officially%20announce%20the%20end%20of%20Flash/Untitled.png](Adobe%20officially%20announce%20the%20end%20of%20Flash/Untitled.png)