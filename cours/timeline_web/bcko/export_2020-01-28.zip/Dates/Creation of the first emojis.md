# Creation of the first emojis

Année: 1997
Catégorie: Launch 🚀
Credits: https://getemoji.com/
Credits: https://fr.wikipedia.org/wiki/%C3%89moji
État: Complet ✅

The first emojis were created in 1997 for SoftBank. Between 1998 and 1999, Shigetaka Kurita, from NTT DoCoMo's i-mode team, created others, which consisted of a 172 emoji game of 12x12 pixels. It has been designed as a specific feature of i-mode messaging, to facilitate electronic communication and to differentiate it from competing services. The use of emojis is constantly increasing. It seems that 4.6% of the messages we exchange on the internet contain at least one emoji.

According to a survey by the Japan Cultural Affairs Agency in 2015, 56.1% of Japanese people have already used emoji, 29% have seen it before without using it and 12.7% have never seen it before .

In 2017, the term "émoji" officially enters the Le Petit Robert dictionary.

According to the website [emojipedia.org](http://emojipedia.org/), there are 2,823 emoji coded in Unicode standard in June 2018

![Creation%20of%20the%20first%20emojis/Untitled.png](Creation%20of%20the%20first%20emojis/Untitled.png)