# Launch of Google Drive, which replaces Google docs

Année: 2012
Catégorie: Launch 🚀
Mois - Jour: 24 avril
État: Complet ✅

Google Drive is a cloud-based storage and sharing service launched by Google. It is an office suite for editing documents, spreadsheets, presentations, drawings, forms, etc.
Google Drive replaces Google Docs when active. Existing documents on Google Docs are automatically uploaded to Google Drive. It is used to synchronize, share and modify data between multiple computers and / or users.

src : [https://fr.wikipedia.org/wiki/Google_Drive](https://fr.wikipedia.org/wiki/Google_Drive)

![Launch%20of%20Google%20Drive%20which%20replaces%20Google%20docs/Untitled.png](Launch%20of%20Google%20Drive%20which%20replaces%20Google%20docs/Untitled.png)