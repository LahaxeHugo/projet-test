# Launch of Google Image Search

Année: 2001
Catégorie: Launch 🚀
Mois - Jour: 1er Juillet

Users can now search for images and photographs on internet.