# End of US presidential campaign marked by attempts at interference

Année: 2016
Catégorie: Publishing 📚
Credits: https://www.huffingtonpost.fr/entry/resultats-de-lelection-americaine-2016-donald-trump-est-elu-pr_fr_5c930c42e4b0da33837e4a2e
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html#date-2018
Mois - Jour: 8 Novembre
État: Complet ✅

The Kremlin has exploited social networks like Facebook to influence the American electorate. The victory of Donald Trump also highlights the effect of "bubble filter" users are locked by algorithms that offer content consistent with their ideologies.

![End%20of%20US%20presidential%20campaign%20marked%20by%20attempts/Untitled.png](End%20of%20US%20presidential%20campaign%20marked%20by%20attempts/Untitled.png)