# Launch of Trello

Année: 2011
Catégorie: Launch 🚀
Mois - Jour: Septembre
État: Complet ✅

Trello is an online project management tool, launched in September 2011 and inspired by Toyota's Kanban method. It is based on an organization of projects in boards listing cards, each representing tasks. The cards are assignable to users and are mobile from one board to another, reflecting their progress.

The basic version is free, while a paid plan provides additional services. The service is available in several languages (23 in June 2016).

src: [https://fr.wikipedia.org/wiki/Trello](https://fr.wikipedia.org/wiki/Trello)

![Launch%20of%20Trello/Untitled.png](Launch%20of%20Trello/Untitled.png)