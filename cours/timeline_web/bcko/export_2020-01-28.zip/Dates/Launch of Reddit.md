# Launch of Reddit

Année: 2005
Catégorie: Launch 🚀
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html
Mois - Jour: Juin
État: Complet ✅

Reddit is one of the most famous forums on the web. It allows users to submit links, photos, videos or articles on which people can vote according its pertinence. Those votes define a score named "karma" that has an impact on the visibility of the link on the website, those with a highest score being on top of the website.
It is also possible to post a message, story or launch a discussion instead of publishing a link.

A comment system is also associated to each post, which allows redditors to react and discuss about the content. Each comment is also submit to the vote system.

Reddit quickly became a place where people use to spread violence, hate, and abusive content such as stolen photos of celebrities, kid pornography, but also misogynistic, transphobic, and racist harassment. It impacted the reputation of the website that became really bad througout the years. 

![Launch%20of%20Reddit/Untitled.png](Launch%20of%20Reddit/Untitled.png)