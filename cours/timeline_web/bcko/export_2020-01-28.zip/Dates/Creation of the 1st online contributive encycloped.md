# Creation of the 1st online contributive encyclopedia : larousse.fr

Année: 2008
Catégorie: Launch 🚀
Mois - Jour: 13 Mai
État: Complet ✅

Launch of [larousse.fr](http://larousse.fr/) website by Larousse publisher, allowing free access to both the encyclopedia and the contributions of clearly identified Internet users. This is the first contributory encyclopaedia on the Internet from a historical encyclopedia.

![Creation%20of%20the%201st%20online%20contributive%20encycloped/Untitled.png](Creation%20of%20the%201st%20online%20contributive%20encycloped/Untitled.png)