# First web page by Tim Berners Lee

Année: 1990
Catégorie: Innovation 🎢
État: Complet ✅

It was dedicated to information on the World Wide Web project and was made by Tim Berners-Lee. It ran on a NeXT computer at the European Organization for Nuclear Research, CERN.

The first web page address was [http://info.cern.ch/hypertext/WWW/TheProject.html.](http://info.cern.ch/hypertext/WWW/TheProject.html)

It outlined how to create Web pages and explained more about hypertext.

Here's what it looked like in 1992 (below). No screenshots were taken of the site before then.

src: [https://www.businessinsider.fr/us/flashback-this-is-what-the-first-website-ever-looked-like-2011-6](https://www.businessinsider.fr/us/flashback-this-is-what-the-first-website-ever-looked-like-2011-6)

![First%20web%20page%20by%20Tim%20Berners%20Lee/Untitled.png](First%20web%20page%20by%20Tim%20Berners%20Lee/Untitled.png)