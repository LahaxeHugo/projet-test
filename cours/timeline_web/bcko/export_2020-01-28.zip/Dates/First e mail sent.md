# First e-mail sent

Année: 1971
Catégorie: Innovation 🎢
Credits: https://www.dolist.com/blog/messaging-transformation-marketing/histoire-de-email-evolution-et-dates-cles/
Credits: https://www.guinnessworldrecords.com/news/60at60/2015/8/1971-first-ever-email-392973?fb_comment_id=911794135560930_1810110339062634/
Mois - Jour: Octobre
État: Complet ✅

In 1965, the e-mail is introduced in the MIT (Massachusetts Institute of Technology). Then in 1971, Ray Tomlinson develops the ARPANET network (ancestor of the Internet), creates an e-mail address and sends his first e-mail on this network. Before, there was no way to send something to a specific person at a specific address.

![First%20e%20mail%20sent/Untitled.png](First%20e%20mail%20sent/Untitled.png)

[https://www.thestar.com/news/world/2016/03/06/ray-tomlinson-inventor-of-modern-email-dies.html](https://www.thestar.com/news/world/2016/03/06/ray-tomlinson-inventor-of-modern-email-dies.html)

Thanks to this event, a standard RFC 733 format is proposed to allow messages to be sent over the Internet. The US Postal Service is starting to see the email as a threat.

The first time someone used the word "e-mail" is in 1982 during the SMTP creation, a communication protocol used to transfer electronic messages and electronic mail servers.

Microsoft Mail for Mac has been launched in 1988, which popularize the concept towards the population.