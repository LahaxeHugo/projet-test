# RSS created

Année: 1997
Catégorie: Launch 🚀
Mois - Jour: Décembre
État: Complet ✅

RSS feeds are based on the XML language and let users subscribe to a Web site's content using an RSS feed reader. They first surfaced as the scriptingNews format, developed by Dave Winer in 1997. In 1999, Netscape developed RSS 0.90 -- a similar XML-based format, but Netscape abandoned the development of the format around the turn of the Millennium. Not only did RSS lead to the accessibility of blogs, but podcasting is by definition reliant on RSS.

src: https://www.cnet.com/news/the-50-most-significant-moments-of-internet-history/

![RSS%20created/Untitled.png](RSS%20created/Untitled.png)