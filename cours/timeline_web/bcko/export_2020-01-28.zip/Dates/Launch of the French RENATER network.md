# Launch of the French "RENATER" network

Année: 1993
Credits: image: http://btsirisinfo.free.fr/topologie/renater.htm
Credits: https://www.renater.fr/fr/histoire
Mois - Jour: 27 Janvier
État: Complet ✅

![Launch%20of%20the%20French%20RENATER%20network/renater.jpg](Launch%20of%20the%20French%20RENATER%20network/renater.jpg)

Renater (the national telecommunications network for technology, education and research) is the French telecommunications network, created by the decree of the 27th January 1993, connecting the various research teaching establishments (universities, research centers) to each other in mainland France and the French overseas departments. 

It gathers major research organizations like CNRS, CPU, CEA, INRIA, CNES, INSERM, ONERA, CIRAD as the Ministry of National Education and Higher Education, Research and Innovation.

Renater can connect more than 1,300 sites via links up to 10 Gbit / s (or even 100 Gbit / s between 2 data centers) in native IPv4 and IPv6.