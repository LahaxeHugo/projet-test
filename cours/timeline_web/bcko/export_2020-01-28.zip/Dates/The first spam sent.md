# The first spam sent

Année: 1978
Catégorie: Publishing 📚
Credits: image: https://www.dmnews.com/marketing-channels/email/article/13035569/an-analysis-of-the-first-spam-email
Credits: https://www.buzzly.fr/le-web-a-25-ans-decouvrez-les-dates-qui-ont-marque-son-histoire.html
Mois - Jour: 3 Mai
État: Complet ✅

![The%20first%20spam%20sent/spam.jpg](The%20first%20spam%20sent/spam.jpg)

Gary Thuerk sends the first unsolicited email to all users on the US West Coast network, at that time 600 people via the ARPANET network. 

However, he did not have bad intentions, but simply wanted to invite the techies users to a demo of the DEC range he was working on, and preferred to add all the addresses at once rather than sending the emails one by one.