# The first images are published on the web

Année: 1992
Catégorie: Images on the web 🖼
Credits: https://www.lemonde.fr/pixels/visuel/2019/03/13/trente-ans-d-innovations-de-scandales-et-de-memes-une-chronologie-du-web_5435444_4408996.html
État: Complet ✅

What was the first image published on the Web? Long before the first pictures of kittens, the kitsch photo of Horribles Cernettes, a CERN music group, went online. But its author, then engineer in the laboratory, has since denied that it could be the first. "Nobody knows what's the first picture on the web. But ours (...) has opened the Web to music and art, and all that is fun! "

![The%20first%20images%20are%20published%20on%20the%20web/Untitled.png](The%20first%20images%20are%20published%20on%20the%20web/Untitled.png)