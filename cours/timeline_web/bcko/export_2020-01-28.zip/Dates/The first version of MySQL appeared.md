# The first version of MySQL appeared

Année: 1995
Catégorie: Launch 🚀
Mois - Jour: 23 Mai