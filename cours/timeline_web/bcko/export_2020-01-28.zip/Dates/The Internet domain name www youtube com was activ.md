# The Internet domain name www.youtube.com was activated

Année: 2005
Catégorie: Launch 🚀
Mois - Jour: 14 Février

[https://youtu.be/jNQXAC9IVRw](https://youtu.be/jNQXAC9IVRw)