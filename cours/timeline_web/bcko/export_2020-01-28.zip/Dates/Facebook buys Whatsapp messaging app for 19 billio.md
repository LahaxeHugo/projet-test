# Facebook buys Whatsapp (messaging app) for $19 billion

Année: 2014
Catégorie: Acquisition 💰
Mois - Jour: 19 Février
État: Complet ✅

This is the biggest acquisition in Facebook's history. Of this total, $ 4 billion will be paid in cash and the remaining $ 12 billion in Facebook shares. The group also plans to pay $ 3 billion in shares to the founders and employees of WhatsApp over a period of four years after the closing of the transaction.
Facebook justifies its decision to buy WhatsApp:
• WhatsApp service has over 450 million monthly users
• 70% of these users are active daily
• more than one million people open an account each day
• The volume of messages sent is approaching the entire SMS volume of global telecom operators, equivalent to 7,000 billion messages per year
• WhatsApp's revenue, although not disclosed (the company is not listed), was estimated by Forbes to be $ 20 million in 2013.

src : [https://www.lemonde.fr/technologies/article/2014/02/19/facebook-achete-la-messagerie-whatsapp-pour-16-milliards-de-dollars_4369701_651865.html](https://www.lemonde.fr/technologies/article/2014/02/19/facebook-achete-la-messagerie-whatsapp-pour-16-milliards-de-dollars_4369701_651865.html)

![Facebook%20buys%20Whatsapp%20messaging%20app%20for%2019%20billio/Untitled.png](Facebook%20buys%20Whatsapp%20messaging%20app%20for%2019%20billio/Untitled.png)